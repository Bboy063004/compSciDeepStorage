import java.util.Scanner;

public class LabProgram {
   
   public static int fibonacci(int n) {
      if (n == 0 || n == 1) {
         return n;
      }
      else if (n < 0) {
         return -1;
      }
      return fibonacciRec(n, 0, 1);
   }

   public static int fibonacciRec(int index, int nm1, int n) {
      if (index == 0) {
         return nm1;
      }
      return fibonacciRec(index - 1, n, n + nm1);
   }

   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      int startNum;
      
      startNum = scnr.nextInt();
      System.out.println("fibonacci(" + startNum + ") is " + fibonacci(startNum));
      scnr.close();
   }
}
