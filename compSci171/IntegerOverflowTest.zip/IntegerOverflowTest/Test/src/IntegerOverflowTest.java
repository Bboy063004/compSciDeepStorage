public class IntegerOverflowTest {
    public static void main(String[] args){
        int num1, num2, num3, num4;
        double result1, result2;
        num1 = 2000000000;
        num2 = 2000000002;
        result1 = (double) (num1 + num2) / 2;
        result2 = (double) (num2 - num1) / 2 + num1;
        System.out.println(result1);
        System.out.println(result2);

    }
}
