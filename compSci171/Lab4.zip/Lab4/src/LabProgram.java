import java.util.Scanner;
public class LabProgram {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        String fullInput = scnr.nextLine();
        String firstName = fullInput.substring(0, fullInput.indexOf(' '));
        String lastName = fullInput.substring(fullInput.indexOf(' ') + 1,
                fullInput.indexOf(' ', fullInput.indexOf(' ') + 1));
        int numbers = Integer.parseInt(fullInput.substring(fullInput.lastIndexOf(' ') + 1));
        char lastInitial = lastName.charAt(0);
        if (firstName.length() >= 6) {
            firstName = firstName.substring(0, 6);
        }
        int loginNum = numbers % 10;
        String login = firstName + lastInitial + "_" + loginNum;
        System.out.print("Your login name: ");
        System.out.println(login);
        scnr.close();
    }
}
