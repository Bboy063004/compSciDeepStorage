import java.util.Scanner;
public class LabProgram1 {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        String fullName = scnr.nextLine();
        int sp1 = fullName.indexOf(' ');
        int sp2 = fullName.lastIndexOf(' ');
        String firstName = fullName.substring(0, sp1);
        String middleName;
        String lastName = fullName.substring(sp2 + 1);
        char firstInitial = firstName.charAt(0);
        char middleInitial;
        if (sp1 != sp2) {
            middleName = fullName.substring(sp1 + 1, sp2);
            middleInitial = middleName.charAt(0);
            System.out.println(lastName + ", " + firstInitial + "." + middleInitial + ".");
        }
        else{
            System.out.println(lastName + ", " + firstInitial + ".");
        }
        scnr.close();
    }
}
