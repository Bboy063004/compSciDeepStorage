import java.util.Scanner;
import java.util.Arrays;

public class LabProgram {

    private static final int NUM_DICE = 5;

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        int diceValues[] = new int[NUM_DICE];
        int highScore = 0;

        // Fill array with five values from input
        for(int i = 0; i < diceValues.length; ++i) {
            diceValues[i] = scnr.nextInt();
        }

        // Find high score and output
        highScore = findHighScore(diceValues);
        System.out.println("High score: " + highScore);
        scnr.close();
    }

    //Gets the amount of rolls per dice value
    public static int[] diceScores( int[] diceRolls) {
        int[] scores = new int[6];

        for (int i = 0; i < diceRolls.length; i++) {
            switch(diceRolls[i]){
                case 1: scores[0]++; break;
                case 2: scores[1]++; break;
                case 3: scores[2]++; break;
                case 4: scores[3]++; break;
                case 5: scores[4]++; break;
                case 6: scores[5]++; break;
            }

        }
        return scores;
    }

    // Find high score
    public static int findHighScore(int dice[]) {
        int highScore = 0;
        int curNum = 0;
        int highestSingle = 0;
        int[] scores = new int[6];
        for (int i = 1; i <= scores.length; i++) {
            curNum = checkSingles(dice, i);
            if (curNum > highestSingle) {
                highestSingle = curNum;
            }
        }
        scores[0] = highestSingle;
        scores[1] = checkThreeOfKind(dice);
        scores[2] = checkFourOfKind(dice);
        scores[3] = checkFiveOfKind(dice);
        scores[4] = checkFullHouse(dice);
        scores[5] = checkStraight(dice);
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > highScore) {
                highScore = scores[i];
            }
        }
        return highScore;
    }

    // Add all occurences of goal value
    public static int checkSingles(int dice[], int goal) {
        int diceScore;
        goal -= 1; // Adjust goal to match array index
        int[] scores = diceScores(dice);
        diceScore = scores[goal] * (goal + 1);
        return diceScore;
    } 

    // Check for three of a kind (score = 30)    
    public static int checkThreeOfKind(int dice[]) {
        int[] scores = diceScores(dice);
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] >= 3) {
                return 30;
            }
        }
        return 0;
    }

    // Check for four of a kind (score = 40)    
    public static int checkFourOfKind(int dice[]) {
        int[] scores = diceScores(dice);
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] >= 4) {
                return 40;
            }
        }
        return 0;
    }

    // Check for five of a kind (score = 50)    
    public static int checkFiveOfKind(int dice[]) {
        int[] scores = diceScores(dice);
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] >= 5) {
                return 50;
            }
        }
        return 0;
    }

    // Check for full house (score = 35)
    public static int checkFullHouse(int dice[]) {
        int[] scores = diceScores(dice);
        boolean hasThree = false;
        boolean hasTwo = false;
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] == 3) {
                hasThree = true;
            } else if (scores[i] == 2) {
                hasTwo = true;
            }
        }
        if (hasThree && hasTwo) {
            return 35;
        }
        return 0;
    }

    // Check for straight (score = 45)    
    public static int checkStraight(int dice[]) {
        int[] scores = diceScores(dice);
        boolean hasOne = false;
        boolean hasTwo = false;
        boolean hasThree = false;
        boolean hasFour = false;
        boolean hasFive = false;
        boolean hasSix = false;
        if (scores[0] == 1) {
            hasOne = true;
        }
        if (scores[1] >= 1) {
            hasTwo = true;
        }
        if (scores[2] >= 1) {
            hasThree = true;
        }
        if (scores[3] >= 1) {
            hasFour = true;
        }
        if (scores[4] >= 1) {
            hasFive = true;
        }
        if (scores[5] >= 1) {
            hasSix = true;
        }
        if ((hasOne || hasSix)&& hasTwo && hasThree && hasFour && hasFive) {
            return 45;
        }
        return 0;
    }
}