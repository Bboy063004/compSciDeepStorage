import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.IOException;

public class LabProgram0 {
    public static void main(String[] args) throws IOException {
        Scanner scnr = new Scanner(System.in);

        int n;
        double average;
        String grade = null;

        // For input of filename
        String infoFileName = null;
        // For input of StudentInfo
        FileInputStream infoStream = null;
        Scanner infoScanner = null;
        // For output of report
        String reportFileName = "report.txt";
        FileOutputStream reportStream = null;
        PrintWriter reportWriter = null;

        // Arrays for score data; assuming no more than 20
        String[] firstNames = new String[20];
        String[] lastNames = new String[20];
        int[] midterm1Scores = new int[20];
        int[] midterm2Scores = new int[20];
        int[] finalScores = new int[20];

        // For computing averages at end of program
        double midterm1Sum;
        double midterm2Sum;
        double finalSum;

        // Get the name of the student information file
        infoFileName = scnr.nextLine();

        /* TODO: Read a file name from the user and read the tsv file here. */
        infoStream = new FileInputStream(infoFileName);
        infoScanner = new Scanner(infoStream);
        n = 0;

        while(infoScanner.hasNext()){
            lastNames[n] = infoScanner.next();
            firstNames[n] = infoScanner.next();
            midterm1Scores[n] = infoScanner.nextInt();
            midterm2Scores[n] = infoScanner.nextInt();
            finalScores[n] = infoScanner.nextInt();
            n++;
        }
        infoStream.close();
        
        


        /* TODO: Compute student grades and exam averages, then output results to a text file here. */
        reportStream = new FileOutputStream(reportFileName);
        reportWriter = new PrintWriter(reportStream);
        for(int i = 0; i < n; i++){
            average = (midterm1Scores[i] + midterm2Scores[i] + finalScores[i]) / 3.0;
            if(average >= 90){
                grade = "A";
            }
            else if(average >= 80){
                grade = "B";
            }
            else if(average >= 70){
                grade = "C";
            }
            else if(average >= 60){
                grade = "D";
            }
            else{
                grade = "F";
            }
            reportWriter.printf("%s\t%s\t%d\t%d\t%d\t%s\n", 
                lastNames[i], firstNames[i], midterm1Scores[i], midterm2Scores[i], finalScores[i], grade);
        }
        midterm1Sum = 0;
        midterm2Sum = 0;
        finalSum = 0;
        for(int i = 0; i < n; i++){
            midterm1Sum += midterm1Scores[i];
            midterm2Sum += midterm2Scores[i];
            finalSum += finalScores[i];
        }
        midterm1Sum /= n;
        midterm2Sum /= n;
        finalSum /= n;
        reportWriter.printf("\nAverages: Midterm1 %.2f, Midterm2 %.2f, Final %.2f\n", 
            midterm1Sum, midterm2Sum, finalSum);
        
        // Close the report file
        reportWriter.flush();
        reportStream.close();
        infoScanner.close();
        scnr.close();

    }
}