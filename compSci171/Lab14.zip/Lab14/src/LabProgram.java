import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;

public class LabProgram {
    public static void main(String[] args) throws IOException {
        Scanner scnr = new Scanner(System.in);
        int NUM_CHARACTERS = 26;      // Maximum number of letters
        int MAX_WORDS = 10;           // Maximum number of synonyms per starting letter

        String[][] synonyms = new String[NUM_CHARACTERS][MAX_WORDS];  // Declare 2D array for all synonyms
        String[] words = new String[MAX_WORDS]; // The words of each input line

        String word;
        String line;
        char inLetter;
        char letter;
        int index;
        int n;

        FileInputStream inputStream = null;
        Scanner inputScanner = null;

        // Read input from the user
        word = scnr.next();
        inLetter = scnr.next().charAt(0);

        // Open the input file for the word
        inputStream = new FileInputStream(word + ".txt");
        inputScanner = new Scanner(inputStream);

        // Store the words of each line
        while (inputScanner.hasNextLine()) {
            line = inputScanner.nextLine();
            words = line.split(" ");

            letter = words[0].charAt(0);
            index = letter - 97;  // Convert letter to corresponding array index (0 - 25)

            // Store synonyms in 2D array
            n = 0;
            for (int i = 0; i < words.length; ++i) {
                synonyms[index][n] = words[i];
                n++;
            }
            // Mark the end of the list with null
            if (n < MAX_WORDS) {
                synonyms[index][n] = null;
            }
        }
        inputScanner.close();
        inputStream.close();

        index = inLetter - 97;    // Convert letter to corresponding array index (0 - 25)

        // Print the synonyms of the word that begin with letter
        // A null indicates the end of a list of synonyms.
        if (synonyms[index][0] == null) {
                System.out.printf("No synonyms for %s begin with %c.\n", word, inLetter);
        }
        else{
            for (int i = 0; i < MAX_WORDS; ++i) {
                if (synonyms[index][i] == null) {
                    break;
                }
                System.out.println(synonyms[index][i]);
            }
            scnr.close();
        }
    }
}
