import java.util.Scanner;

/**
 * AuthoringAssistant.java
 * This program provides a text-based menu for users to analyze and manipulate a given string.
 * It includes options to count non-whitespace characters, count words, find text, replace characters,
 * and shorten spaces.
 * Author: Bobby Wienke
 * Date: 10/13/2025
 * Course: CS 171
 * I got an extra submission for talking in class.
 */
public class AuthoringAssistant {
    /**
     * Displays the menu options to the user.
     */
    public static void printMenu() {
        System.out.println("MENU");
        System.out.println("c - Number of non-whitespace characters");
        System.out.println("w - Number of words");
        System.out.println("f - Find text");
        System.out.println("r - Replace all !'s");
        System.out.println("s - Shorten spaces");
        System.out.println("q - Quit");
        System.out.println();
    }
    /**
     * Executes the menu option chosen by the user.
     * 
     * @param choice The menu option chosen by the user.
     * @param text The text to be analyzed or manipulated.
     * @param scnr The Scanner object for user input.
     */
    public static String executeMenu(char choice, String text, Scanner scnr) {
        switch (choice) {
            case 'c':
                System.out.println("Number of non-whitespace characters: " + getNumOfNonWSCharacters(text));
                break;
            case 'w':
                System.out.println("Number of words: " + getNumOfWords(text));
                break;
            case 'f':
                System.out.println("Enter a word or phrase to be found:");
                String searchString = scnr.nextLine();
                System.out.println("\"" + searchString + "\" instances: " + findText(searchString, text));
                break;
            case 'r':
                text = replaceExclamation(text);
                break;
            case 's':
                text = shortenSpace(text);
                System.out.println("Edited text: " + text);
                break;
        }
        return text;
    }
    /**
     * Counts the number of non-whitespace characters in the given text.
     * 
     * @param text The text to be analyzed.
     * @return The number of non-whitespace characters.
     */
    public static int getNumOfNonWSCharacters(String text) {
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (!Character.isWhitespace(c)) {
                count++;
            }
        }
        return count;
    }
    /**
     * Counts the number of words in the given text.
     * 
     * @param text The text to be analyzed.
     * @return The number of words.
     */
    public static int getNumOfWords(String text) {
        text = shortenSpace(text);
        int count = 0;
        if(text.charAt(0) != ' ') {
            count++;
        }
        while (text.indexOf(' ') != -1) {
            count++;
            text = text.substring(text.indexOf(' ') + 1);
        }
        return count;
    }
    
    /**
     * Finds and counts the occurrences of a search string within the given text.
     * 
     * @param text The text to be searched.
     * @param scnr The Scanner object for user input.
     */
    public static int findText(String searchString, String text) {
        int count = 0;
        text = shortenSpace(text);
        while (text.indexOf(searchString) != -1) {
            count++;
            text = text.substring(text.indexOf(searchString) + searchString.length());
        }
        return count;
    }
    /**
     * Replaces all exclamation marks in the given text with periods.
     * 
     * @param text The text to be modified.
     * @return The modified text with exclamation marks replaced by periods.
     */
    public static String replaceExclamation(String text) {
        while (text.indexOf('!') != -1) {
            text = text.replace('!', '.');
        }
        System.out.println("Edited text: " + text);
        return text;
    }
    /**
     * Shortens multiple consecutive spaces in the given text to a single space.
     * 
     * @param text The text to be modified.
     * @return The modified text with shortened spaces.
     */
    public static String shortenSpace(String text) {
        while (text.indexOf("  ") != -1) {
            text = text.replace("  ", " ");
        }
        return text;
    }

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        String inputString;
        char menuChoice = ' ';
        final char ESCAPE_CHAR = 'q';

        // Get string from user
        System.out.println("Enter a sample text:");
        inputString = scnr.nextLine();
        System.out.println();
        System.out.println("You entered: " + inputString);

        while(menuChoice != ESCAPE_CHAR) {
            // Print menu
            System.out.println();
            printMenu();
            menuChoice = ' '; // reset menu choice
            // Get valid menu choice from user
            while(menuChoice != 'c' && menuChoice != 'w' && menuChoice != 'f' && menuChoice != 'r' && menuChoice != 's' && menuChoice != 'q') {
                System.out.println("Choose an option:");
                menuChoice = scnr.nextLine().charAt(0);
                //scnr.nextLine(); // clear newline
            }
            // Process menu choice
            inputString = executeMenu(menuChoice, inputString, scnr);
        }
    }
}
