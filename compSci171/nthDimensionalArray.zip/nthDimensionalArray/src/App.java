/**
 * This program initializes a 5-dimensional array and iterates through all its elements,
 * printing the coordinates of each element in a formatted manner. It also counts the total
 * number of elements in the array.
 * @author Bobby Wienke
 */
public class App {

    public static void main(String[] args) throws Exception {
        int[][][][][] myArray = new int[4][4][4][4][4];
        int count = 0;
        int x, y, z, α, β;
        for (int i = 0; i < myArray.length; i++) {
            x = i;
            for (int j = 0; j < myArray[i].length; j++) {
                y = j;
                for (int k = 0; k < myArray[i][j].length; k++) {
                    z = k;
                    for (int l = 0; l < myArray[i][j][k].length; l++) {
                        α = l;
                        for (int m = 0; m < myArray[i][j][k][l].length; m++) {
                            β = m;
                            System.out.print("(" + x + "," + y + "," + z + "," + α + "," + β + ")");
                            count++;
                        }
                        System.out.println();
                    }
                }
                System.out.println();
            }
            System.out.println();
        }
        System.out.println("Total count: " + count);
    }
}
