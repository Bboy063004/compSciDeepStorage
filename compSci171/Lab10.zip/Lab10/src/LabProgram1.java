import java.util.Scanner;

public class LabProgram1 {
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      int first = scnr.nextInt(),
         second = scnr.nextInt();
      SimpleCar car = new SimpleCar();
      car.honkHorn();
      car.drive(first);
      car.report();
      car.honkHorn();
      car.reverse(second);
      car.report();
      scnr.close();
      
   }
}
