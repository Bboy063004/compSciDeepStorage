import java.util.Scanner;

public class TriangleArea {
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      
      Triangle triangle1 = new Triangle();
      Triangle triangle2 = new Triangle();

      double t1b = scnr.nextDouble();
      double t1h = scnr.nextDouble();
      double t2b = scnr.nextDouble();
      double t2h = scnr.nextDouble();

      // TODO: Read and set base and height for triangle1 (use setBase() and setHeight())
      triangle1.setBase(t1b);
      triangle1.setHeight(t1h);

      // TODO: Read and set base and height for triangle2 (use setBase() and setHeight())
      triangle2.setBase(t2b);
      triangle2.setHeight(t2h);
      scnr.close();
      
      System.out.println("Triangle with smaller area:");

      if (triangle1.getArea() < triangle2.getArea()) {
         triangle1.printInfo();
      } else {
         triangle2.printInfo();
      }

   }
}
