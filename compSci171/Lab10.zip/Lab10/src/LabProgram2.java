import java.util.Scanner;

public class LabProgram2 {
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      int first = scnr.nextInt(),
         second = scnr.nextInt(),
         third = scnr.nextInt();
      VendingMachine vm = new VendingMachine();
      vm.purchase(first);
      vm.restock(second);
      vm.purchase(third);
      vm.report();
      scnr.close();
   }
}
