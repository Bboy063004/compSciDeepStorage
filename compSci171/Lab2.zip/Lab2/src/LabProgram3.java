import java.util.Scanner;
public class LabProgram3{
    public static void main(String[] args){
        Scanner scnr = new Scanner(System.in);
        int num1, num2, num3, num4;
        int sum, avg, product;
        double dblAvg, dblProduct;
        num1 = scnr.nextInt();
        num2 = scnr.nextInt();
        num3 = scnr.nextInt();
        num4 = scnr.nextInt();
        sum = num1 + num2 + num3 + num4;
        product = num1 * num2 * num3 * num4;
        avg = sum / 4;
        System.out.println(product + " " + avg);

        dblProduct = (double)num1 * num2 * num3 * num4;
        dblAvg = (double)sum / 4;

        System.out.printf("%.3f %.3f\n", dblProduct, dblAvg);
        scnr.close();
    }
}
