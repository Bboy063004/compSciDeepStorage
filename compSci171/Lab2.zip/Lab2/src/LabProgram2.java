import java.util.Scanner;
public class LabProgram2{
    public static void main(String[] args) throws Exception {
        Scanner scrn = new Scanner(System.in);
        Double xIn, yIn, zIn, xToZ, absY, xToYSqrd, theOtherOne;

        xIn = scrn.nextDouble();
        yIn = scrn.nextDouble();
        zIn = scrn.nextDouble();

        xToZ = Math.pow(xIn, zIn);
        xToYSqrd = Math.pow(xIn,Math.pow( yIn, zIn));
        absY = Math.abs(yIn);
        theOtherOne = Math.sqrt(Math.pow((xIn * yIn), zIn));

        System.out.print(xToZ + " ");
        System.out.print(xToYSqrd + " ");
        System.out.print(absY + " ");
        System.out.println(theOtherOne);

        scrn.close();
    }
}
