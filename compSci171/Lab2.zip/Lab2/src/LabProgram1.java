import java.util.Scanner;
public class LabProgram1{
    public static void main(String[] args) throws Exception {
        Scanner scrn = new Scanner(System.in);
        int age, weight, heartRate, time;
        double calories;

        age = scrn.nextInt();
        weight = scrn.nextInt();
        heartRate = scrn.nextInt();
        time = scrn.nextInt();

        calories = ((age * 0.2757 + weight * 0.03295 + heartRate * 1.0781 - 75.4991) * time) / 8.368;

        System.out.print("Calories: ");
        System.out.printf("%.2f", calories);
        System.out.println(" calories");

        scrn.close();
    }
}
