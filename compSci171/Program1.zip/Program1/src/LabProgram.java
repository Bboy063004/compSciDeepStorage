import java.util.Scanner;
/*
* Give a short yet precise description of what your program does.
* @author Bobby Wienke
*/
public class LabProgram {
    public static void main(String[] args) {
        int wage, interest, unemployment, status, withheld, agi, refund, taxableIncome, taxDue, deduction = 24000;
        double taxAmount;
        final int SINGLE = 12000, LONGER_TAX_FORM_REQUIRED = 120000;
        boolean error, isPositiveTaxable;
        Scanner scnr = new Scanner(System.in);
        wage = scnr.nextInt();
        interest = scnr.nextInt();
        unemployment = scnr.nextInt(); 
        status = scnr.nextInt();
        withheld = scnr.nextInt();
        agi = wage + interest + unemployment;
        error = agi > LONGER_TAX_FORM_REQUIRED;
        System.out.printf("AGI: $%,d\n", agi);
        if (error) {
            System.out.println("Error: Income too high to use this form");
        }
        else {
            if (status == 2) {
                taxableIncome = agi - deduction;            //|these are not redundant
                isPositiveTaxable = taxableIncome > 0;      //|
                if (!isPositiveTaxable) {                   //|
                    taxableIncome = 0;                      //\/
                }
                if (taxableIncome <= 20000) {
                    taxAmount = Math.round(taxableIncome * 0.1);
                }
                else if (taxableIncome <= 80000) {
                    taxAmount = 2000 + Math.round((taxableIncome - 20000) * 0.12);
                }
                else {
                    taxAmount = 9200 + Math.round((taxableIncome - 80000) * 0.22);
                }
            }
            else {
                deduction = SINGLE;
                taxableIncome = agi - deduction;            //|these are not redundant
                isPositiveTaxable = taxableIncome > 0;      //|
                if (!isPositiveTaxable) {                   //|
                    taxableIncome = 0;                      //\/
                }
                if (taxableIncome <= 10000) {
                    taxAmount = Math.round(taxableIncome * 0.1);
                }
                else if (taxableIncome <= 40000) {
                    taxAmount = 1000 + Math.round((taxableIncome - 10000) * 0.12);
                }
                else if (taxableIncome <= 85000) {
                    taxAmount = 4600 + Math.round((taxableIncome - 40000) * 0.22);
                }
                else {
                    taxAmount = 14500 + Math.round((taxableIncome - 85000) * 0.24);
                }
            }
            System.out.printf("Deduction: $%,d\n", deduction);
            System.out.printf("Taxable income: $%,d\n", taxableIncome);
            System.out.printf("Federal tax: $%,d\n", (int) taxAmount);
            taxDue = withheld - (int) taxAmount;
            if(taxDue < 0) {
                taxDue = -taxDue;
                System.out.printf("Tax due: $%,d\n", taxDue);
            }
            else {
                refund = taxDue;
                System.out.printf("Tax refund: $%,d\n", refund);
            }
        }
        scnr.close();
    }
}
