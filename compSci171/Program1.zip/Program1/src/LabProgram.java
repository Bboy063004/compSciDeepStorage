import java.util.Scanner;
/*
* Give a short yet precise description of what your program does.
* @author Bobby Wienke
*/
public class LabProgram {
    public static void main(String[] args) {
        int wage, interest, unemployment, status, withheld, agi, refund, taxableIncome, taxDue, deduction = 24000;
        final int SINGLE_BRACKET1 = 10000, SINGLE_BRACKET2 = 40000, SINGLE_BRACKET3 = 85000;
        final int MARRIED_BRACKET1 = 20000, MARRIED_BRACKET2 = 80000;
        final double RATE1 = 0.1, RATE2 = 0.12, RATE3 = 0.22, RATE4 = 0.24;
        double taxAmount;
        final int SINGLE = 12000, LONGER_TAX_FORM_REQUIRED = 120000;
        boolean error, isPositiveTaxable;
        Scanner scnr = new Scanner(System.in);
        wage = scnr.nextInt();
        interest = scnr.nextInt();
        unemployment = scnr.nextInt(); 
        status = scnr.nextInt();
        withheld = scnr.nextInt();
        agi = wage + interest + unemployment;
        error = agi > LONGER_TAX_FORM_REQUIRED;
        System.out.printf("AGI: $%,d\n", agi);
        if (error) {
            System.out.println("Error: Income too high to use this form");
        }
        else {
            if (status == 2) {
                taxableIncome = agi - deduction;            //|these are not redundant
                isPositiveTaxable = taxableIncome > 0;      //|
                if (!isPositiveTaxable) {                   //|
                    taxableIncome = 0;                      //\/
                }
                if (taxableIncome <= MARRIED_BRACKET1) {
                    taxAmount = Math.round(taxableIncome * RATE1);
                }
                else if (taxableIncome <= MARRIED_BRACKET2) {
                    taxAmount = 2000 + Math.round((taxableIncome - MARRIED_BRACKET1) * RATE2);
                }
                else {
                    taxAmount = 9200 + Math.round((taxableIncome - MARRIED_BRACKET2) * RATE3);
                }
            }
            else {
                deduction = SINGLE;
                taxableIncome = agi - deduction;            //|these are not redundant
                isPositiveTaxable = taxableIncome > 0;      //|
                if (!isPositiveTaxable) {                   //|
                    taxableIncome = 0;                      //\/
                }
                if (taxableIncome <= SINGLE_BRACKET1) {
                    taxAmount = Math.round(taxableIncome * RATE1);
                }
                else if (taxableIncome <= SINGLE_BRACKET2) {
                    taxAmount = 1000 + Math.round((taxableIncome - SINGLE_BRACKET1) * RATE2);
                }
                else if (taxableIncome <= SINGLE_BRACKET3) {
                    taxAmount = 4600 + Math.round((taxableIncome - SINGLE_BRACKET2) * RATE3);
                }
                else {
                    taxAmount = 14500 + Math.round((taxableIncome - SINGLE_BRACKET3) * RATE4);
                }
            }
            System.out.printf("Deduction: $%,d\n", deduction);
            System.out.printf("Taxable income: $%,d\n", taxableIncome);
            System.out.printf("Federal tax: $%,d\n", (int) taxAmount);
            taxDue = withheld - (int) taxAmount;
            if(taxDue < 0) {
                taxDue = -taxDue;
                System.out.printf("Tax due: $%,d\n", taxDue);
            }
            else {
                refund = taxDue;
                System.out.printf("Tax refund: $%,d\n", refund);
            }
        }
        scnr.close();
    }
}
