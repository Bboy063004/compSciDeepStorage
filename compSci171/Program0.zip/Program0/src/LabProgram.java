import java.util.Scanner;

public class LabProgram {
    public static void main(String[] args) {
        int numPeople1, numPeople2, numPeople3, numPizzas1, numPizzas2, numPizzas3;
        double avgSlices1, avgSlices2, avgSlices3, pricePerPizza1, pricePerPizza2, pricePerPizza3, pizzaCost1, pizzaCost2, pizzaCost3, subtotal1, subtotal2;
        double subtotal3, totalCost1, totalCost2, totalCost3, tax1, tax2, tax3, delivery1, delivery2, delivery3, grandTotal;
        Scanner scandral = new Scanner(System.in);
        final int SLICES = 8;
        numPeople1 = scandral.nextInt();
        avgSlices1 = scandral.nextDouble();
        pricePerPizza1 = scandral.nextDouble();
        numPeople2 = scandral.nextInt();
        avgSlices2 = scandral.nextDouble();
        pricePerPizza2 = scandral.nextDouble();
        numPeople3 = scandral.nextInt();
        avgSlices3 = scandral.nextDouble();
        pricePerPizza3 = scandral.nextDouble();
        numPizzas1 = (int)Math.ceil((numPeople1 * avgSlices1) / SLICES);
        numPizzas2 = (int)Math.ceil((numPeople2 * avgSlices2) / SLICES);
        numPizzas3 = (int)Math.ceil((numPeople3 * avgSlices3) / SLICES);
        pizzaCost1 = numPizzas1 * pricePerPizza1;
        pizzaCost2 = numPizzas2 * pricePerPizza2;
        pizzaCost3 = numPizzas3 * pricePerPizza3;
        tax1 = pizzaCost1 * 0.07;
        tax2 = pizzaCost2 * 0.07;
        tax3 = pizzaCost3 * 0.07;
        subtotal1 = tax1 + pizzaCost1;
        subtotal2 = tax2 + pizzaCost2;
        subtotal3 = tax3 + pizzaCost3;
        delivery1 = subtotal1 * 0.20;
        delivery2 = subtotal2 * 0.20;
        delivery3 = subtotal3 * 0.20;
        totalCost1 = subtotal1 + delivery1;
        totalCost2 = subtotal2 + delivery2;
        totalCost3 = subtotal3 + delivery3;
        grandTotal = totalCost1 + totalCost2 + totalCost3;
        System.out.println("Friday Night Party");
        System.out.printf("%d Pizzas: $%.2f\n",numPizzas1, pizzaCost1);
        System.out.printf("Tax: $%.2f\n", tax1);
        System.out.printf("Delivery: $%.2f\n", delivery1);
        System.out.printf("Total: $%.2f\n\n", totalCost1);
        System.out.println("Saturday Night Party");
        System.out.printf("%d Pizzas: $%.2f\n",numPizzas2, pizzaCost2);
        System.out.printf("Tax: $%.2f\n", tax2);
        System.out.printf("Delivery: $%.2f\n", delivery2);
        System.out.printf("Total: $%.2f\n\n", totalCost2);
        System.out.println("Sunday Night Party");
        System.out.printf("%d Pizzas: $%.2f\n",numPizzas3, pizzaCost3);
        System.out.printf("Tax: $%.2f\n", tax3);
        System.out.printf("Delivery: $%.2f\n", delivery3);
        System.out.printf("Total: $%.2f\n\n", totalCost3);
        System.out.printf("Weekend Total: $%.2f\n", grandTotal);
        scandral.close();
    }
}
