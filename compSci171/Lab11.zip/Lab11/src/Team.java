public class Team {
   // TODO: Declare private fields - name, wins, losses
   private String name;
   private int wins, losses;
   
   // TODO: Define mutator methods - 
   //       setName(), setWins(), setLosses()
   public void setName(String name){
      this.name = name;
   }
   
   public void setWins(int wins){
      this.wins = wins;
   }

   public void setLosses(int losses){
      this.losses = losses;
   }
   // TODO: Define accessor methods - 
   //       getName(), getWins(), getLosses()
   public String getName(){
      return this.name;
   }
   
   public int getWins(){
      return this.wins;
   }

   public int getLosses(){
      return this.losses;
   }
   // TODO: Define getWinPercentage()
   public double getWinPercentage(){
      return (double)wins/(wins + losses);
   }
   
   // TODO: Define printStanding()
   public void printStanding(){
      double winPercent = getWinPercentage();
      System.out.printf("Win percentage: %.2f\n", winPercent);
      if(winPercent < .5){
         System.out.print("Team " + name + " has a losing average.");
      }
      else{
         System.out.println("Congratulations, Team " + name + " has a winning average!");
      }

   }
}