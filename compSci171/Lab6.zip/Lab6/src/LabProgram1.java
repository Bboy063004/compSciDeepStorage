import java.util.Scanner;
public class LabProgram1 {
    public static void main(String[] args){
        Scanner scnr = new Scanner(System.in);
        String input = scnr.nextLine(), usedString = input;
        while(usedString.indexOf(" ") != -1) {
            usedString = usedString.replace(" ", "");
        }
        for (int i = 0; i < usedString.length() / 2; ++i) {
            if (usedString.charAt(i) != usedString.charAt(usedString.length() - 1 - i)) {
                System.out.print("not a ");
                break;
            }
        }
        System.out.println("palindrome: " + input);
        scnr.close();
    }
}
