import java.util.Scanner;
public class LabProgram {
    public static void main(String[] args){
        Scanner scnr = new Scanner(System.in);
        int a = scnr.nextInt(), b = scnr.nextInt(), c = scnr.nextInt(), 
            d = scnr.nextInt(), e = scnr.nextInt(), f = scnr.nextInt(), x, y;
        boolean found = false;
        for (x = -10; x <= 10; ++x) {
            for (y = -10; y <= 10; ++y) {
                if (a * x + b * y == c && d * x + e * y == f) {
                    System.out.println("x = " + x + ", y = " + y);
                    found = true;
                }

            }
        }
        if (!found) {
            System.out.println("There is no solution");
        }
        scnr.close();
    }
}
