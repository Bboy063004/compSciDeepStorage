import java.util.ArrayList;

public class Course {

    private ArrayList<Student> roster; //collection of Student objects

    public Course() {
        roster = new ArrayList<Student>();
    }

    // Outputs each student in the course roster, and then the total size of the course
    public void printRoster() {
        int i, j, maxIdx;
        
        
        /* Put your code here */
        //selection sort to sort roster by student names
        for(i = 0; i < roster.size() - 1; i++) {
            maxIdx = i;
            for (j = i + 1; j < roster.size(); j++) {
                Student max = roster.get(maxIdx);
                Student s = roster.get(j);
                if (s.getGPA() > max.getGPA() ||
                    (s.getGPA() - max.getGPA() < .0001 && s.getLast().compareTo(max.getLast()) < 0) ||
                    (s.getLast().equals(max.getLast()) && s.getFirst().compareTo(max.getFirst()) < 0)) {
                    maxIdx = j;
                }
            }
            //swap
            Student temp = roster.get(i);
            roster.set(i, roster.get(maxIdx));
            roster.set(maxIdx, temp);
        }
        
        //print the roster using an enhanced for loop
        for(Student s : roster) {
            System.out.println(s);
        }

        //print total number of students in the course
        System.out.println("Students: " + roster.size());
    }

    public void addStudent(Student s) {
        roster.add(s);
    }
}