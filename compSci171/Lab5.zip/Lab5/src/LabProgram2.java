import java.util.Scanner;

public class LabProgram2 {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);

        int max = Integer.MIN_VALUE;
        long sum = 0;
        int count = 0;

        while (scnr.hasNextInt()) {
            int val = scnr.nextInt();
            if (val < 0) {
                break; // negative integer ends input and is not included
            }
            sum += val;
            count++;
            if (val > max) {
                max = val;
            }
        }

        double average = (double) sum / count;
        System.out.printf("%d %.2f\n", max, average);
    }
}
