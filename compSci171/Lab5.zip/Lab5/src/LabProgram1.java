import java.util.Scanner;

public class LabProgram1 {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        int intIn = scnr.nextInt();

        StringBuilder reverseBinary = new StringBuilder();
        while (intIn > 0) {
            reverseBinary.append(intIn % 2);
            intIn = intIn / 2;
        }

        System.out.println(reverseBinary.toString());
    }
}
