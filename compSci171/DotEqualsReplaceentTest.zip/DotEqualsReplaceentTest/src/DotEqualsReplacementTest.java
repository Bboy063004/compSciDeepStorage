public class DotEqualsReplacementTest {
    public static void main(String[] args){
        String s = "beans";
        String t = "beansease";
        boolean equalsZero;
        boolean equalsOther;
        equalsZero = s.indexOf(t) == 0 && t.indexOf(s) == 0;
        equalsOther = s.indexOf(t) == t.indexOf(s);
        System.out.println(equalsZero);
        System.out.println(equalsOther);
    }
}
