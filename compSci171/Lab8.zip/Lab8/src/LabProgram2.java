import java.util.Scanner;

public class LabProgram2 {
    public static void main(String[] args){
        Scanner scnr = new Scanner(System.in);
        int n = scnr.nextInt();

        int[] arrayA = new int[n], arrayC = new int[n];
        int[][] arrayB = new int[n][n];

        for (int i = 0; i < n; i++){
            arrayA[i] = scnr.nextInt();
        }
        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){
                arrayB[i][j] = scnr.nextInt();
            }
        }
        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){
                arrayC[i] += arrayA[j] * arrayB[j][i];
            }
        }
        for (int i = 0; i < n; i++) {
            System.out.print(arrayC[i] + " ");
        }
        System.out.println();
    }
}
