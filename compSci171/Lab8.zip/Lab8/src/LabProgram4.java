public class LabProgram4{
    public static void main(String[] args) {
        int[] array = new int[] { 1, 2, 3, 4, 5 };
        int[] evens = removeOdds(array);
        for(int i = 0; i < evens.length; i++){
            System.out.print(evens[i] + " ");
        }
    }

    public static int[] removeOdds(int[] array) {
        
        int count = 0;
        int iteration = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i] % 2 == 0) {
                count++;
            }
        }
        int[] evens = new int[count];
        for(int i = 0; i < array.length; i++){
            if(array[i] % 2 == 0 ){
                evens[iteration] = array[i];
                iteration++;
            }
        }
        return evens;
    }
}