import java.util.Scanner;

public class LabProgram1 {
    public static void main(String[] args){
        Scanner scnr = new Scanner(System.in);
        int stringLength = scnr.nextInt();

        String[] inArray = new String[stringLength];
        int[] stringCount = new int[stringLength];

        for (int i = 0; i < stringLength; i++) {
            inArray[i] = scnr.next();
        }
        for (int i = 0; i < inArray.length; i++) {
            for (int j = 0; j < inArray.length; j++) {
                if (inArray[i].equals(inArray[j])) {
                    stringCount[i]++;
                }
            }
        }
        for (int i = 0; i < stringCount.length; i++) {
            System.out.println(inArray[i] + " - " + stringCount[i]);
        }
    }
}
