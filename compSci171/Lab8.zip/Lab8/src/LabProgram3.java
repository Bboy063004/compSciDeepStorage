public class LabProgram3 {
    public static void main(String[] args){
        int[] input = new int[] { 2, 4, 6 };
        int[] reversed = new int[input.length];
        reversed = reverse(input);
        for (int i = 0; i < reversed.length; i++){
            System.out.print(reversed[i] + " ");
        }
    }

    public static int[] reverse(int[] array){
        int[] reversed = new int[array.length];
        for (int i = 0; i < array.length; i++){
            reversed[i] = array[array.length - 1 - i];
        }
        return reversed;
    }
}
