import java.util.Scanner; 

public class LabProgram1 {
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in); 
      int highwayNumber;
      int primaryNumber;
      boolean isEastWest;

      highwayNumber = scnr.nextInt();
      
      primaryNumber = highwayNumber % 100;
      isEastWest = (primaryNumber % 2 == 0);
      if (highwayNumber < 1 || highwayNumber > 999 || primaryNumber == 0) {
         System.out.println(highwayNumber + " is not a valid interstate highway number.");
      } 
      else if (highwayNumber < 100) {
         if (isEastWest) {
            System.out.println("I-" + highwayNumber + " is primary, going east/west.");
         }
         else{
            System.out.println("I-" + highwayNumber + " is primary, going north/south.");
         }
      } else {
         if (isEastWest) {
            System.out
                  .println("I-" + highwayNumber + " is auxiliary, serving I-" + primaryNumber + ", going east/west.");
         } else {
            System.out
                  .println("I-" + highwayNumber + " is auxiliary, serving I-" + primaryNumber + ", going north/south.");
         }
      }
      scnr.close();
   }
}
