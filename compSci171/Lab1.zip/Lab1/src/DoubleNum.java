import java.util.Scanner;
public class DoubleNum {
    public static void main(String[] args) throws Exception {
        Scanner scnr = new Scanner(System.in);
        int numToDouble;
        int numDoubled;
        System.out.println("Enter x: ");
        numToDouble = scnr.nextInt();
        numDoubled = 2 * numToDouble;
        System.out.println("x doubled is: " + numDoubled);
        scnr.close();
    }
}
