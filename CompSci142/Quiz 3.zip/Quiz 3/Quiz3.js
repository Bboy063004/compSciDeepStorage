function compute(){
	var number, result;
	number = document.getElementById('number').value;
	result = Math.pow(number, 3);
	document.getElementById('output').innerHTML = result;
}