//Define all your javascript in this file, as separate functions, appropriately named.
function cs142Info() {
  //do something
  alert('Instructor: Scott Summers')
}
function mathInfo() {
  //do something
  alert('Instructor: Ed Clemons')
}
function writingInfo() {
  //do something
  alert('Instructor: Bijan Salamati')
}
function acadInfo() {
  //do something
  alert('Instructor: Lisa Marchetta')
}
function wagsInfo() {
  //do something
  alert('Instructor: Jeffrey Filipiak')
}
function bandInfo() {
  //do something
  alert('Instructor: Joseph Scheivert')
}
function showEmail() {
	document.getElementById('title').innerHTML = 'wienkebo48@uwosh.edu';
}
function hideEmail() {
	document.getElementById('title').innerHTML = "Bobby's Schedule";
}