var canvasColor;
var x = 20;
var y = 20;
var dx = 5;
var dy = 2;
var sdx, sdy, radius, status;

function start(){
	var canvas, pen;
	canvas = document.getElementById('Canvas');
	pen = canvas.getContext('2d');
	canvasColor = '#00FFFF';
	radius = 18;
	pen.fillStyle = canvasColor;
	pen.fillRect(0,0,400,400);
	setInterval('drawCircle()',25);
	
}

function resume(){
	dx = sdx;
	dy = sdy;
}

function pause(){
	sdx = dx;
	sdy = dy;
	dx = 0;
	dy = 0;
}

function drawCircle(){
	var canvas, pen;
	canvas = document.getElementById('Canvas');
	pen = canvas.getContext('2d');
	pen.fillStyle = canvasColor;
	pen.beginPath();
	pen.arc(x,y,radius+2,0,2*Math.PI); 
	pen.fill();
	x += dx;		
	y += dy;
	if (x > (canvas.width-21)){
		dx = randomValue(-1);

	}
	else if (x < 21){
		dx = randomValue(1);
	}
	if (y > (canvas.height-21)){
		dy = randomValue(-1);
	}
	else if (y < 21){
		dy = randomValue(1);
	}
	pen.fillStyle = 'Orange';
	pen.beginPath();
	pen.arc(x,y,radius,0,2*Math.PI); 
	pen.fill();
}

function randomValue(a){
	var value;
	value = a * ((Math.random()*4)+1);
	return value;
}