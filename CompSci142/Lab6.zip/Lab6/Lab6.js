var totalRolls = 0;
var totalSum = 0;
var number1, number2, number3;
function roll(){
	var sum = 0;
	number1 = Math.floor(6 * Math.random() + 1);
	number2 = Math.floor(6 * Math.random() + 1);
	number3 = Math.floor(6 * Math.random() + 1);
	setImage(number1, '1');
	setImage(number2, '2');
	setImage(number3, '3');
	sum = number1 + number2 + number3;
	increaseTotals(sum);
}
function increaseTotals(sum){
		totalRolls += 1;
		totalSum += sum;
		displayTotals(totalRolls, totalSum);
}
	
function setImage(number, imageId){
	document.getElementById('die' + imageId).src = 'images/die' + number +'.gif';
}

function displayTotals(rolls, sum){
		document.getElementById('output').innerHTML = "You have rolled the dice " + rolls + 
					" times, and accumulated a total of " + sum + ".";
}