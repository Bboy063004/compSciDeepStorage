//javascript document
//movement speed
var movex = 1;
var movey = 1;
//positioning
var balx, baly;
var bar1y, bar2y, w, s, i, k;
//score
var score1 = 0;
var score2 = 0;
//loop
var loop;


function load() {
    var c = document.getElementById("gameArea");
    var draw = c.getContext("2d");
    //background
    draw.beginPath();
    draw.rect(0,0,400,400);
    draw.fillStyle = "#DFF2FF";
    draw.fill();
    draw.strokeStyle = "#DFF2FF";
    draw.stroke();
    //left bar 
    bar1y = 160;

    draw.beginPath();
    draw.rect(20,bar1y,10,80);
    draw.fillStyle = "black";
    draw.fill();
    draw.stroke();
 
    //right bar
    bar2y = 160;

    draw.beginPath();
    draw.rect(370,bar2y,10,80);
    draw.fillStyle = "black";
    draw.fill();
    draw.stroke();

    }

function play() {
    //ball start position
    balx = 200;
    baly = 200;
    loop = setInterval(move,25);
}

function move() {
    var c = document.getElementById("gameArea");
    var draw = c.getContext("2d");

    //erase prev ball
    draw.beginPath();
    // (x, y, radius, start angle, end angle)
    draw.arc(balx, baly, 10 , 0, 2 * Math.PI);
    draw.fillStyle = "#DFF2FF";
    draw.fill();
    draw.strokeStyle = "#DFF2FF";
    draw.stroke();

    //erase old bar 1
    draw.beginPath();
    draw.rect(20,bar1y,10,80);
    draw.fillStyle = "#DFF2FF";
    draw.fill();
    draw.strokeStyle = "#DFF2FF";
    draw.stroke();

    //erase old bar 2
    draw.beginPath();
    draw.rect(370,bar2y,10,80);
    draw.fillStyle = "#DFF2FF";
    draw.fill();
    draw.strokeStyle = "#DFF2FF";
    draw.stroke();

    
    //check wall collisons
    if(5 >= baly + movey || baly + movey >= 395) {
        movey = -movey;
    }
    // (bar 1 x, check if it collides with bar 1 y || bar 2 x, check if it collides with bar 2 y)
    if((40 >= balx && !(bar1y >= baly || baly >= bar1y + 80)) || (balx >= 360 && !(bar2y >= baly || baly >= bar2y + 80))){
        if (movex == 1 || movex == -1) {
            movex = -5*movex
        }
        else {
            movex = -movex;
        }
        //get the output trajectory
        if (balx <= 200) {
        movey = ((baly - bar1y - 40)/5);
        }
        else if (balx >= 200) {
        movey = ((baly - bar2y - 40)/5);
        }
    }

    //new ball position
    balx += movex;
    baly += movey;

    //get input
    window.addEventListener("keydown", (down) => {
        if (down.key == 'w'){
            w = 0;
        }
        if (down.key == 's'){
            s = 0;
        }
        if (down.key == 'i'){
            i = 0;
        }
        if (down.key == 'k'){
            k = 0;
        }
    })

    window.addEventListener ("keyup", (up) => {
        if (up.key == "w"){
            w = 1;
        }
        if (up.key == 's'){
            s = 1;
        }
        if (up.key == 'i'){
            i = 1;
        }
        if (up.key == 'k'){
            k = 1;
        }
    })

    if (w == 0 && bar1y >= 0) {
        bar1y -= 7;
    }
    if (s == 0 && bar1y + 80 <= 400) {
        bar1y += 7;
    }
    if (i == 0 && bar2y >= 0) {
        bar2y -= 7;
    }
    if (k == 0 && bar2y + 80 <= 400) {
        bar2y += 7;
    }

    //bar 1 move
    draw.beginPath();
    draw.rect(20,bar1y,10,80);
    draw.fillStyle = "black";
    draw.fill();
    draw.stroke();

    //bar 2 move
    draw.beginPath();
    draw.rect(370,bar2y,10,80);
    draw.fillStyle = "black";
    draw.fill();
    draw.stroke();

    //draw new ball
    draw.beginPath();
    draw.arc(balx, baly, 10, 0, 2 * Math.PI);
    draw.fillStyle = "orange";
    draw.fill();
    draw.stroke();

    if( 0 >= balx + movex || balx + movex >= 400) {
        if(0 >= balx + movex) {
            alert("player 2 Scores!");
            movex = -1;
            score2++
            document.getElementById("score2").innerHTML = score2;
        }
        else if(balx + movex >= 400){
            alert("player 1 Scores!");
            movex = 1
            score1++
            document.getElementById("score1").innerHTML = score1;
        }
        clearInterval(loop);
        //erase prev ball
        draw.beginPath();
        draw.arc(balx, baly, 10, 0, 2 * Math.PI);
        draw.fillStyle = "#DFF2FF";
        draw.fill();
        draw.strokeStyle = "#DFF2FF";
        draw.stroke();
        //reset all
        w = 1;
        s = 1;
        i = 1;
        k = 1;
    }
}
