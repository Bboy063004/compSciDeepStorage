function calculate(){
	var crd1_1, crd1_2, crd2_1, crd2_2, subcrd1, subcrd2, sqcrd1, sqcrd2, addsqrs, sqrtrslt, result;
	crd1_1 = document.getElementById('coord1_1').value;
	document.getElementById('coord1_1out').innerHTML = crd1_1;
	crd1_2 = document.getElementById('coord1_2').value;
	document.getElementById('coord1_2out').innerHTML = crd1_2;
	crd2_1 = document.getElementById('coord2_1').value;
	document.getElementById('coord2_1out').innerHTML = crd2_1;
	crd2_2 = document.getElementById('coord2_2').value;
	document.getElementById('coord2_2out').innerHTML = crd2_2;
	subcrd1 = crd1_1 - crd2_1;
	subcrd2 = crd1_2 - crd2_2;
	sqcrd1 = subcrd1 * subcrd1;
	sqcrd2 = subcrd2 * subcrd2;
	addsqrs = sqcrd1 + sqcrd2;
	sqrtrslt = Math.sqrt(addsqrs);
	result = Math.round(sqrtrslt*100)/100;
	document.getElementById('output').innerHTML = result;
}

function populate(){
	document.getElementById('coord1_1').value = Math.floor(100 * Math.random() + 1);
	document.getElementById('coord2_1').value = Math.floor(100 * Math.random() + 1);
	document.getElementById('coord1_2').value = Math.floor(100 * Math.random() + 1);
	document.getElementById('coord2_2').value = Math.floor(100 * Math.random() + 1);
	}