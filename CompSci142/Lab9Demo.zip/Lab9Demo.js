var canvasColor;
var x,y,radius;

function startup()
{
	//Initialize
	canvasColor = '#A3C2C2';
	x = 10;
	y = 100;
	radius = 15;
	clearScreen();
	setInterval('drawEverything()',200);
}

function drawEverything()
{
	drawCircle();
	drawRectangle();
}

function clearScreen()
{
	var canvas, pen;
	
	canvas = document.getElementById('myCanvas');
	pen = canvas.getContext('2d');	
	pen.fillStyle = canvasColor;
	pen.fillRect(0,0,400,400);
	
}


function drawCircle()
{
	var canvas, pen;
	
	canvas = document.getElementById('myCanvas');
	pen = canvas.getContext('2d');

	//Erase the previous circle
	pen.fillStyle = canvasColor;
	pen.beginPath();
	pen.arc(x,y,radius+2,0,2*Math.PI); 
	pen.fill();
	
	//Draw a new circle
	x = x + 10;
	if (x > canvas.width)
	{
		//reset x
		x = 0;
	}
	pen.fillStyle = '#FF0000';
	pen.beginPath();
	pen.arc(x,y,radius,0,2*Math.PI); 
	pen.fill();
	
	
}


function drawRectangle()
{
	var canvas, pen;
	var topX,leftY,width,height;
	var r,g,b;
	
	canvas = document.getElementById('myCanvas');
	pen = canvas.getContext('2d');
	
	//Set up a random color
	r = Math.floor(Math.random()*256);
	g = Math.floor(Math.random()*256);
	b = Math.floor(Math.random()*256);
	pen.fillStyle = 'rgb('+r+','+g+','+b+')';
	
	//draw a random rectangle
	topX = Math.floor(Math.random()*canvas.width);
	leftY = Math.floor(Math.random()*canvas.height);
	width = Math.floor(Math.random()*canvas.width);
	height = Math.floor(Math.random()*canvas.height);
	
	pen.fillRect(topX,leftY,width,height);

}

function drawShape()
{
	var canvas, pen;
	
	canvas = document.getElementById('myCanvas');
	pen = canvas.getContext('2d');
	
	//Draw rectangle
	pen.fillStyle = '#0000FF';
	pen.fillRect(0,100,200,100);
	
	
	//Draw circle
	pen.fillStyle = '#FF0000';
	pen.beginPath();
	pen.arc(50,50,25,0,2*Math.PI); //x,y,radius,startangle,endangle
	pen.fill();
	
	
}























