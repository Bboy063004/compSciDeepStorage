function getMessage(opt){
	var temp1, temp2, wind, humidity, message;
	temp1 = document.getElementById('temp1').value;
	temp2 = document.getElementById('temp2').value;
	wind = document.getElementById('wind').value;
	humidity = document.getElementById('humidity').value;
	if(opt == 1){
		if((isNaN(temp1))||(isNaN(humidity))){
			message = 'please enter valid values';
		}
		else if((humidity < 0)||(humidity > 100)){
			message = 'Please enter a valid humidity';
		}
		else{
			message = 'The dewpoint is ' + calcDew(temp1, humidity) + "&deg;F";
		}
	}
	if(opt == 2){
		if((isNaN(temp2))||(isNaN(wind))){
			message = 'please enter valid values';
		}
		else if(temp2 > 50){
			message = 'Temperature is too high';
		}
		else if(wind <= 3){
			message = 'Wind speed it too slow';
		}
		else{
			message = 'The windchill is ' + calcWind(document.getElementById('temp2').value, document.getElementById('wind').value) + "&deg;F";
		}
	}
	document.getElementById('output' + opt).innerHTML = message;
}
function calcDew(temp, humidity){
	var result;
	result = (temp-((100-humidity)/2.778));
	return result;
}
function calcWind(temp, wind){
	var result;
	result = (35.74 + (0.6215 * (temp)) + (((0.4375 * (temp)) - 35.75) * (Math.pow(wind, 0.16))));
	return result;
}