function compute(){
	var input, sub, mult, divd;
	input = document.getElementById('fahren').value;
	sub = input - 32;
	mult = sub * 5;
	divd = mult / 9;
	document.getElementById('output').innerHTML = divd;
	}