var result, inA, inB, inC, inD;

function add(){
	inA=parseFloat(document.getElementById('inputA').value);
	inB=parseFloat(document.getElementById('inputB').value);
	inC=parseFloat(document.getElementById('inputC').value);
	inD=parseFloat(document.getElementById('inputD').value);
	result=inA+inB+inC+inD;
	document.getElementById('solution').innerHTML=result;
}

function subtract(){
	inA=parseFloat(document.getElementById('inputA').value);
	inB=parseFloat(document.getElementById('inputB').value);
	inC=parseFloat(document.getElementById('inputC').value);
	inD=parseFloat(document.getElementById('inputD').value);
	result=inA-inB-inC-inD;
	document.getElementById('solution').innerHTML=result;
}

function multiply(){
	inA=parseFloat(document.getElementById('inputA').value);
	inB=parseFloat(document.getElementById('inputB').value);
	inC=parseFloat(document.getElementById('inputC').value);
	inD=parseFloat(document.getElementById('inputD').value);
	if (inA==0){inA=1};
	if (inB==0){inB=1};
	if (inC==0){inC=1};
	if (inD==0){inD=1};
	result=inA*inB*inC*inD;
	document.getElementById('solution').innerHTML=result;
}

function divide(){
	inA=parseFloat(document.getElementById('inputA').value);
	inB=parseFloat(document.getElementById('inputB').value);
	inC=parseFloat(document.getElementById('inputC').value);
	inD=parseFloat(document.getElementById('inputD').value);
	if (inA==0){inA=1};
	if (inB==0){inB=1};
	if (inC==0){inC=1};
	if (inD==0){inD=1};
	result=inA/inB/inC/inD;
	document.getElementById('solution').innerHTML=result;
}