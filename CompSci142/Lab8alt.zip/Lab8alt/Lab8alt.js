function getMessage(opt, temp, wind, humidity){
	var message;
	if(opt == 1){
		if((isNaN(temp))||(isNaN(humidity))||(temp=='')||(humidity=='')){
			message = 'Please enter valid values';
		}
		else if((humidity < 0)||(humidity > 100)){
			message = 'Please enter a valid humidity';
		}
		else{
			message = 'The dewpoint is ' + calcDew(temp, humidity) + "&deg;F";
		}
	}
	if(opt == 2){
		if((isNaN(temp))||(isNaN(wind))||(temp=='')||(wind=='')){
			message = 'Please enter valid values';
		}
		else if(temp > 50){
			message = 'Temperature is too high';
		}
		else if(wind <= 3){
			message = 'Wind speed it too slow';
		}
		else{
			message = 'The windchill is ' + calcWind(temp, wind) + "&deg;F";
		}
	}
	document.getElementById('output' + opt).innerHTML = message;
}
function calcDew(temp, humidity){
	var result;
	result = (temp-((100-humidity)/2.778));
	return result;
}
function calcWind(temp, wind){
	var result;
	result = (35.74 + (0.6215 * (temp)) + (((0.4275 * (temp)) - 35.75) * (Math.pow(wind, 0.16))));
	return result;
}