function doSomething()
{
	document.getElementById('output').innerHTML = 'This has changed';
	document.getElementById('output').style = 'color:red';
}

function showFree()
{
	document.getElementById('mystery').src = 'images/free.jpg';
	document.getElementById('myName').innerHTML = 'lynchk@uwosh.edu';
}

function showNotFree()
{
	document.getElementById('mystery').src = 'images/notfree.jpg';
	document.getElementById('myName').innerHTML = 'Kathy Lynch';
}























