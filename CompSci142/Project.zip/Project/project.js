var canvasColor;
var stepsElapsed=0;
var difficulty = 35;
var barx = 200;
var move = 0;
const balls = [];
const activeBalls = [];
var numOfBalls = 0;
var counter = 0;
var burst = 0, escaped = 0, result = 0;
class ball{
	constructor(inx, iny, inc, test){
		this.x = inx;
		this.y = iny;
		this.color = inc;
		this.active = test;
	}
}
function startGame(){
	var canvas, pen;
	canvas = document.getElementById('myCanvas');
	pen = canvas.getContext('2d');
	canvasColor = '#EAEDDC';
	pen.fillStyle = canvasColor;
	pen.fillRect(0,0,450,300);
	setInterval('gameStep();', 50);
	for (let i = 0; i < 100; i++){
		balls[i] = new ball (Math.ceil((Math.random()*400)+25), -5, getRandomColor(), false);
	}
}

function drawBall(ballx, bally, ballcolor){
	var canvas, pen;
	canvas = document.getElementById('myCanvas');
	pen = canvas.getContext('2d');
	pen.fillStyle = ballcolor;
	pen.beginPath();
	pen.arc(ballx, bally, 10, 0, 2*Math.PI);
	pen.fill();
}

function getRandomColor(){
	const letters = '0123456789ABCDEF';
	let color = '#';
	for (let i = 0; i < 6; i++) {
		color += letters[Math.floor(Math.random() * 16)];
	}
	return color;
}

function gameStep(){
	if(burst+escaped<100){
	var canvas, pen;
	canvas = document.getElementById('myCanvas');
	pen = canvas.getContext('2d');
	pen.fillStyle = canvasColor;
	pen.fillRect(0,0,450,300);
	stepsElapsed+=1;
	document.getElementById('steps').innerHTML = 'Steps elapsed: ' + stepsElapsed;
	if(barx < 20 && move == -20){
		move = 0;
	}
	else if(barx > 380 && move == 20){
		move = 0;
	}
	else{
		barx+=move;
	}
	pen.fillStyle = 'blue';
	pen.fillRect(barx, 250, 50, 10);
	if(counter < difficulty){
		counter +=1;
	}
	else if(counter >= difficulty){
		if (numOfBalls<100){
			balls[numOfBalls].active = true;
			activeBalls[numOfBalls] = balls[numOfBalls];
			
			numOfBalls+=1;
			counter = 0;
		}
	}
	for (let i = 0; i<numOfBalls; i++){
		if(activeBalls[i].active == true){
			drawBall(activeBalls[i].x, activeBalls[i].y, activeBalls[i].color);
			checkCollision(i)
		}
	}
	for (let i = 0; i < numOfBalls; i++){
		activeBalls[i].y+=2;
	}
	document.getElementById('burst').innerHTML = 'Burst: ' + burst;
	document.getElementById('escaped').innerHTML = 'Escaped: ' + escaped;
	}
	else{
		document.getElementById('output').innerHTML = burst + '% popped'
	}
}

function checkCollision(num){
	if((((activeBalls[num].y+10)==249)||((activeBalls[num].y-10)==249)||((activeBalls[num].y)==249)||((activeBalls[num].y-5)==249)||((activeBalls[num].y+5)==249))&&
	((activeBalls[num].x+10>barx)&&(activeBalls[num].x-10<barx+50))){
		activeBalls[num].active = false;
		burst+=1;
	}
	else if(activeBalls[num].y >= 300){
		escaped+=1;
		activeBalls[num].active = false;
	}
	console.log(num);
}

function moveLeft(){
	move = -20;
}

function moveRight(){
	move = 20;
}

function stopMove(){
	move = 0;
}

function check(d){
	if(d == 'easy'){
		difficulty = 35;
	}
	else if(d == 'moderate'){
		difficulty = 20;
	}
	else if(d == 'hard'){
		difficulty = 10;
	}
}