//Define all you javascript in this file, as separate functions, appropriately named.
function cs142Info() {
  //do something
  alert('Instructor: Kathy Lynch')
}
function mathInfo() {
  //do something
  alert('Instructor: Fearase Alniemi')
}
function writingInfo() {
  //do something
  alert('Instructor: Kelley Duhatschek')
}
function esInfo() {
  //do something
  alert('Instructor: Shannon Davis-Foust')
}
function marchingBandInfo() {
  //do something
  alert('Instructor: Joseph Scheivert')
}
function bandInfo() {
  //do something
  alert('Instructor: Devin Otto')
}
function showEmail() {
	document.getElementById('title').innerHTML = 'wienkebo48@uwosh.edu';
}
function hideEmail() {
	document.getElementById('title').innerHTML = "Bobby's Schedule";
}