function compute(){
	var number, result;
	
	//input
	number = parseFloat(document.getElementById('op1').value);
	
	//process
	//result = Math.round(number*100)/100;
	result =  Math.floor(6 * Math.random() + 1);
	
	//output
	document.getElementById('output').innerHTML = result;
	
}















