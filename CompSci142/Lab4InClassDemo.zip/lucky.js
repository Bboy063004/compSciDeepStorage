function generateNumber(){
	min=parseFloat(document.getElementById('minBox').value);
    max=parseFloat(document.getElementById('maxBox').value);
    number=Math.floor(Math.random()*(max-min+1)) + min;
    document.getElementById('outputDiv').innerHTML=
             'Your lucky number is ' + number;
}