function roll()
{
	var number;
	number = Math.floor(6 * Math.random() + 1);
	
	document.getElementById('die').src = 
			'images/die' + number +'.gif';
}