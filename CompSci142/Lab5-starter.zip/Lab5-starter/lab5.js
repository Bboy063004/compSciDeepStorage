
function setImage(imgId, imgSrc)
{
   //alert("Setting img=" + imgId + " to " + imgSrc);

   
   
   
   
   
}

function roll()
{
  
  
  
  
  
  
}