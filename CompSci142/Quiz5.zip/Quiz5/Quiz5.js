function message(){
	var name,yob,pob,answer;
	name = document.getElementById('name').value;
	yob = document.getElementById('yob').value;
	pob = document.getElementById('pob').value;
	answer = createMessage(pob,yob,name);
	document.getElementById('output').innerHTML = answer;
}
function createMessage(pob, yob, name){
	var message;
	message = "Hi " + name + ", you were born in " + yob + " in " + pob + ".";
	return(message);
}