//This is my first javascript block of code
function sayWelcome()
{
	alert('Welcome to cs 142');
}
