//This is my first javascript block of code
function changeText()
{
	document.getElementById("output").innerHTML =
			'Changed it!';
}
