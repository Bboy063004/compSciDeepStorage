var correct = 0;
var total = 0;
function Check(shapeIn)
{
	var number, shape;
	number = Math.floor(4 * Math.random() + 1);
	if(number == 1){
		shape = 'square';
	}
	else if(number == 2){
		shape = 'triangle';
	}
	else if(number == 3){
		shape = 'circle';
	}
	else{
		shape = 'star';
	}
	document.getElementById('mysteryImg').src = "images/" + shape + ".gif";
	total++;
	if(shapeIn == number){
		document.getElementById('output').innerHTML = 'Your guess was correct.';
		correct++;
	}
	else{
		document.getElementById('output').innerHTML = 'Sorry, wrong guess.';
	}
	document.getElementById('correctSpan').innerHTML = correct;
	document.getElementById('totalSpan').innerHTML = total;
	document.getElementById('percentSpan').innerHTML = (correct/total)*100;
}