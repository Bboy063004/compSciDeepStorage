function display()
{
	document.getElementById('output').style = 
					'color:red;text-align:center;';
	document.getElementById('output').innerHTML = 'Modified';
}

function enlarge()
{
	document.getElementById('resize').height=200;
	document.getElementById('resize').width=200;
}

function shrink()
{
	document.getElementById('resize').height=85;
	document.getElementById('resize').width=85;	
}















