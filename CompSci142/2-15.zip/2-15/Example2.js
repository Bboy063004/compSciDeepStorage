function display()
{	
	//declare our variables
	var myName,courseName,topics, answer;
	
	//get input
	myName = document.getElementById('nameBox').value;
	courseName = document.getElementById('courseBox').value;
	topics = document.getElementById('topicBox').value;
	
	//do processing
	answer = 'Hello, ' + myName + 
			 '. Welcome to ' + courseName +
			 '. You will learn about ' + topics + '\'';
	
	//display output
	document.getElementById('output').innerHTML = answer;
	
}












