function rollTriples()
{
	var roll1,roll2,roll3;
	roll1=1;
	roll2=2;
	roll3=3;
	document.getElementById('output').innerHTML = '';
	
	while(roll1 != roll2 || roll2 != roll3 || roll3 != roll1)
	{
		roll1 = Math.floor(1 + Math.random()*6);
		roll2 = Math.floor(1 + Math.random()*6);
		roll3 = Math.floor(1 + Math.random()*6);
		document.getElementById('output').innerHTML += 
			roll1 + '--' + roll2 + '--' + roll3 + '<br>';
	}
	//roll1 == roll2 == roll3
	document.getElementById('output').innerHTML += 'TRIPLES';
}

function sumNumbers()
{
	var start,stop,sum,counter,str;
	
	start = parseFloat(document.getElementById('start').value);
	stop = parseFloat(document.getElementById('stop').value);
	
	sum = 0;
	counter = start;
	str='<tr><th>Counter</th><th>Sum</th></tr>';
	while(counter <= stop)
	{
		sum = sum + counter;
		str += '<tr><td>' + counter + '</td><td>' + sum + '</td></tr>'
		counter = counter + 1;
		
	}
	document.getElementById('output').innerHTML =
				'<table border="3">'+ str +'</table>';
				
	document.getElementById('output').innerHTML += 'Final sum = '+sum;
}
				
	
	





















