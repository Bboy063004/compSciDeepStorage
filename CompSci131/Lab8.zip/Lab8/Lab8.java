
/**
 * given an amount of numbers, compute the average, minimum, maximum, 
 * and count of positive and negative numbers
 *
 * @author Bobby Wienke
 * @version 4/17/2026
 */
import java.util.Scanner;

public class Lab8 {
    public static void main(String[] args) {

        // setup any variables that we might need
        double sum = 0; // Note the double type used here
        int count = 0;
        int totalNumberCount;
        int userInput;
        int[] inputs;
        double average; // Note the double type used here
        int max;
        int min;
        int negatives = 0;
        int positives = 0;

        // Declare and initialize Scanner object
        Scanner scan = new Scanner(System.in);

        // Prompt the user to enter the total number count
        System.out.println("Enter the total number count: ");
        totalNumberCount = scan.nextInt();
        inputs = new int[totalNumberCount];

        // loop that reads a number from the user and adds it to sum:
        while (count < totalNumberCount) {
            System.out.println("Enter the next number: ");
            userInput = scan.nextInt();
            inputs[count] = userInput;

            // update cumulative sum with this new input
            sum = sum + userInput;

            count = count + 1;
        }

        // Find the maximum and minimum values
        max = inputs[0];
        min = inputs[0];

        for (int i = 0; i < inputs.length; i++) {
            if (inputs[i] > max) {
                max = inputs[i];
            }
            if (inputs[i] < min) {
                min = inputs[i];
            }
            if (inputs[i] < 0) {
                negatives++;
            }
            if (inputs[i] > 0) {
                positives++;
            }

        }
        // Compute and display the average
        average = sum / totalNumberCount;
        System.out.println("Average = " + average);
        System.out.println("Minimum = " + min);
        System.out.println("Maximum = " + max);
        System.out.println("Negatives = " + negatives);
        System.out.println("Positives = " + positives);
    }
}
