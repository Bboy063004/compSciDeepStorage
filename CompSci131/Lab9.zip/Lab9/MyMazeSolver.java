/**
 * maze dude moves until hes gone forwards 10 times, then goes back to where he started
 *
 * @author Bobby Wienke
 * @version 4/27/2026
 */
public class MyMazeSolver extends MazeSolver {
    private static final int NORTH = 0;
    private static final int EAST = 1;
    private static final int SOUTH = 2;
    private static final int WEST = 3;
    private static final int NUM_DIRECTIONS = 4;    
    private static final int MAX_MOVES = 10;
    
    private int totalWeight = 0;
    private int forwardMoves = 0;
    private int currentDirection = NORTH;
    private int[] moves = new int[MAX_MOVES];
    private boolean inBackTrackMode = false;    //boolean variable to keep track if we are in backtrack phase
    
    public void takeTurn() {
        int weightOfItem = getWeightOfItem();
        if ( isItemAvailableToPickUp() && totalWeight + weightOfItem <= MAX_WEIGHT ){
            pickUpItem(); 
            totalWeight = totalWeight + weightOfItem;
        }
        else if (forwardMoves < MAX_MOVES && !inBackTrackMode){ //move forward if you have not exceeded max moves, AND are not in backtrack phase
            if ( canMoveForward() ) {
                moveForward();
                
                //1 - code to store the opposite of current direction in the position in moves array, indexed by forwardMoves
                //...
                moves[forwardMoves] = (currentDirection + 2) % NUM_DIRECTIONS;
                
                //Increment forward moves
                forwardMoves = forwardMoves + 1;
                //If you hit max moves, then you must enter backtrack phase
                if (forwardMoves == MAX_MOVES){
                    inBackTrackMode = true;    
                }
            }
            else { //blocked, so you must turn to continue trying to move forward
                turnRight();
                
                //2 - code to update current direction accordingly here
                //...
                currentDirection = (currentDirection + 1) % NUM_DIRECTIONS;
            }           
        }
        else { //backtrack phase now
            //Code to backtrack using the opposite direction values stored in moves, and then to finally giveup  
            //First, begin aligning currentDirection with stored opposite direction, likely over multiple steps
            if (currentDirection != moves[forwardMoves-1]){
                    turnRight(); 
                    currentDirection = currentDirection + 1;
                    if (currentDirection == NUM_DIRECTIONS) {
                        currentDirection = NORTH;
                    }                        
            }
            else { //currentDirection now aligned with opposite direction
                //Move forward and decrement forwardMoves
                moveForward();
                forwardMoves = forwardMoves - 1;
                //Check if we backtracked all the way, if so, give up
                if (forwardMoves == 0){
                    System.out.println("Giving up");
                    giveUp();
                } 
                
            }
        }      
    }

    public String getName() { return "Bobby Wienke"; }

    public void reset() { 
        //Re-initialize all relevant private variables here
        totalWeight = 0;
        forwardMoves = 0;
        currentDirection = NORTH;
        moves = new int[MAX_MOVES];   
        inBackTrackMode = false;
    }

    public static void main(String[] args) {
        TheAmazingRace.play( new MazeSolver[]{ new MyMazeSolver() } );
    }
}
