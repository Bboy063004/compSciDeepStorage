
/**
 * Write a description of class MyMazeSolver here.
 *
 * @author Bobby W.
 * @version 03/13/2026
 */
public class MyMazeSolver extends MazeSolver {
    private int totalWeight = 0;
    private int forwardMoves = 0;
    public void takeTurn() {
        int weightOfItem = getWeightOfItem();
        if ( weightOfItem > 0 && totalWeight + weightOfItem <= MAX_WEIGHT ) {
            pickUpItem();
            totalWeight += weightOfItem;
        }
		else if ( canMoveForward() ) {
			moveForward();
            forwardMoves++;
		}
		else{ // limit consecutive right turns to 4
			turnRight();
		}
        
    }
    
    public String getName() { return "Bobby W."; }
    
    public void reset() { }
    
    public static void main(String[] args) {
        TheAmazingRace.play( new MazeSolver[]{ new MyMazeSolver() } );
    }
}
