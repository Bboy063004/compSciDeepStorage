/**
 * Write a description of Lab7 here.
 *
 * @author Bobby W
 * @version 4/3/26
 */
//Imports necessary to use the Random and Scanner objects
import java.util.Random;
import java.util.Scanner;

public class Lab7 {

    public static void main(String [] args){
        //Initialize Random and Scanner objects
        Random rand = new Random();       
        Scanner scan = new Scanner(System.in);
        
        //Declare and initialize other variables you need
        final int MAX_GUESSES = 10;
        int curGuess = 0;
        boolean guessedCorrectly = false;
        
        //Choose a random number to be the secret number - this is the computer's choice
        
        int secretNumber = rand.nextInt(100) + 1; // generates a random number between 1 and 100
        //....
        System.out.println("I have chosen a secret number in the range 1-100. You have 10 guesses");        
        
        // Implement the algorithm outlined below, or your version:

		// Algorithm outline
        while(!guessedCorrectly && curGuess < MAX_GUESSES){
            System.out.println("What is your guess?");
            int userGuess = scan.nextInt();
            curGuess++;
            
            if(userGuess < secretNumber){
                System.out.printf("Too low! You have %d guesses remaining.\n", MAX_GUESSES - curGuess);
            } else if(userGuess > secretNumber){
                System.out.printf("Too high! You have %d guesses remaining.\n", MAX_GUESSES - curGuess);
            } else {
                System.out.printf("You got it! You've used %d guesses to guess the secret number %d\n", curGuess, secretNumber);
                guessedCorrectly = true;
            }
        }
        // Loop that does the following:
        //      read a guess from the user - use scan.nextInt() to read an integer input from the user
        //      check if the user input is less than, greater than or equal to the secret number, printing an appropriate message
        //      keep a count of the guesses made so far
        //      exit from the loop if the user exceeds the allowed guess count, or the user has guessed correctly and the game is over
        //      otherwise continue in loop and get a new guess from the user, etc.  
        
        // After loop: 
        // if guess count is equal to max allowed, the user failed to guess correctly in allotted guesses, so print appropriate message

        scan.close();
    }
}