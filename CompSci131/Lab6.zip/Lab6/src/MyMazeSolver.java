
/**
 * It does tha maze until it gets back to where it started and it gives up
 *
 * @author Bobby Wienke
 * @version 3/20/2026
 */
public class MyMazeSolver extends MazeSolver {
    //These are constants that you should use in your code
    public static final int NORTH = 0;
    public static final int EAST = 1;
    public static final int SOUTH = 2;
    public static final int WEST = 3;
    public static final int NUM_DIRECTIONS = 4;
    
    //Instance variables you will need
    private int currentDirection = NORTH;
    private int totalWeight = 0;
    //Define any other instance variables  you need here:
    private int xFromOrig = 0;
    private int yFromOrig = 0;
    private boolean giveUpNext = false;
    
    public void takeTurn() {        
        int weightOfItem = getWeightOfItem();
        // Code that handles picking up items, observing weight restrictions    
        if( giveUpNext ){
            giveUp();
        }
        else if ( isItemAvailableToPickUp() && totalWeight + weightOfItem <= MAX_WEIGHT ){           
            pickUpItem(); 
            totalWeight += weightOfItem;
        }       
        else if ( canMoveForward() ){
            moveForward();
            //Your code goes here
            switch(currentDirection){
                case NORTH:
                    yFromOrig += 1;
                    break;
                case EAST:
                    xFromOrig += 1;
                    break;
                case SOUTH:
                    yFromOrig -= 1;
                    break;
                case WEST:
                    xFromOrig -= 1;
                    break;                    
            }
            if( xFromOrig == 0 && yFromOrig == 0 ){
                //We are back at the start, give up
                giveUpNext = true;
            }
        }
        else {           
                turnRight();
                //Keep track of direction                    
                currentDirection = currentDirection + 1;
                if ( currentDirection == NUM_DIRECTIONS  ) {
                     currentDirection = NORTH;
                }
        }
    }    

    public String getName() { 
        //Edit the line below to include your name
        return "Bobby Wienke"; 
    }

    public void reset() { }

    public static void main(String[] args) {
        TheAmazingRace.play( new MazeSolver[]{ new MyMazeSolver() } );
    }
}
