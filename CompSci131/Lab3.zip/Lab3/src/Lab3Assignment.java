/** 
 * This does a thing
 * 
 * @author Bobby Wienke
 * @version 1.0
 * @date 2024-06-01
 */
public class Lab3Assignment {
    public static void main(String[] args) throws Exception {
        System.out.println("BBBBBB");
        System.out.println("B     B");
        System.out.println("B     B");
        System.out.println("BBBBBB");
        System.out.println("B     B");
        System.out.println("B     B");
        System.out.println("BBBBBB");
        
    }
}
