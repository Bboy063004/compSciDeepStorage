for(i=0 ;i<=9; i++ ){
    console.log("goodbye");
}