#include "stdio.h"
int main(void) {

   unsigned short int input;     // variable declaration
   unsigned short int amount;
   unsigned short int tracker;

   printf("Enter an integer between 0 and 65535: "); // display a prompt
   scanf("%iu", &input);         // read unsigned short into age

   tracker = input;
   while(tracker > 0){
	if(tracker%2==1){
	   amount = amount + 1;
	}
	tracker = tracker/2;
   }

   printf("# of 1's in a 16-bit representation of %i: %i\n", input, amount); // print value of age
   return 0; // exit with normal termination (no error) code
}
