import java.util.Scanner;
/**
 * A program that outputs all factors of a user defined number
 *
 * @author Bobby Wienke
 * @version 04/04/2024
 */
public class FactorFinder
{
    public static void main(String[] args)
    {
        //variables
        Scanner scandalous = new Scanner(System.in);
        int factor;
        int prime = 0;
        
        //ask user for starting number
        System.out.print("Find factors for: ");
        factor = scandalous.nextInt();
        
        //output 1
        if(factor > 0)
            {
                System.out.print("1");
            }
            
        //find the factors
        for(int i = 2; i <= factor; i++)
        {
            if((factor % i) == 0)
            {
                prime++;
                System.out.print(", " + i);
            }
        }
        if(prime < 2)
        {
            System.out.println("\n" + factor + " is prime");
        }
    }
}
