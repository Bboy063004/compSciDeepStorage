import java.util.Scanner;
/**
 * a program the shows the smallest factors of a user defined number
 *
 * @author Bobby Wienke
 * @version 04/05/2024
 */
public class SmallestFactorFinder
{
    public static void main(String[] args)
    {
        //variables
        Scanner pairOfScandals = new Scanner(System.in);
        int factor;
        int curFactor = 2;
        
        //ask for starting number
        System.out.print("Find factors for: ");
        factor = pairOfScandals.nextInt();
        
        if(factor > 0)
        {
            System.out.print("1");
            while(curFactor != factor)
            {
                if(factor % curFactor == 0)
                {
                    System.out.print("  " + curFactor);
                    factor = factor / curFactor;
                }
                else
                {
                    curFactor++;
                }
            }
            System.out.print("  " + factor);
        }
    }
}
