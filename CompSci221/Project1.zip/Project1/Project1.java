import java.util.Scanner;
/**
 * A program to determine if a babys weight is healthy, compared to its age
 *
 * @author Bobby Wienke
 * @version 04/04/2024
 */
public class Project1
{
    public static void main(String[] args)
    {
        //Variables
        Scanner scandra = new Scanner(System.in);
        int formatChoice;
        double weight;
        double healthyUpper;
        double healthyLower;
        double age;
        boolean tooYoung = false;
        boolean tooOld = false;
        boolean weightInvalid = false;
        
        //intorduction
        System.out.println("Welcome to the Infant Weight Evaluator!");
        
        //ask for choice of formating
        System.out.println("Which units would you like to use to enter " + 
                            "in the age and weight?");
        System.out.println("1: months and kg");
        System.out.println("2: years and kg");
        System.out.println("3: months and pounds");
        System.out.println("4: years and pounds");
        System.out.print("Choice #: ");
        formatChoice = scandra.nextInt();
        
        
        switch (formatChoice) {
            case 1:
                //ask for age
                System.out.print("Enter in the age in months: ");
                age = scandra.nextDouble();
                if(age < 0)
                {
                    tooYoung = true;
                }
                else if(age > 24)
                {
                    tooOld = true;
                }
                else
                {
                    //age is valid, ask for weight
                    System.out.print("Enter weight in kg: ");
                    weight = scandra.nextDouble();
                    //determine healthy limits based on entered weight
                    healthyUpper = ((5*age)/12)+5;
                    healthyLower = (age/3)+2;
                    if(weight < 2 || weight > 15)
                    {
                        weightInvalid = true;
                    }
                    else
                    {
                        if(weight <= healthyUpper && weight >= healthyLower)
                        {
                            System.out.println("Age/weight is in the healthy" + 
                            " range!");
                        }
                        else if(weight > healthyUpper)
                        {
                            System.out.println("Too heavy");
                        }
                        else if(weight < healthyLower)
                        {
                            System.out.println("Too light");
                        }
                    }
                }
                break;
            
            case 2:
                //ask for age
                System.out.print("Enter in the age in years: ");
                age = scandra.nextDouble();
                //convert years to months
                age = age * 12;
                if(age < 0)
                {
                    tooYoung = true;
                }
                else if(age > 24)
                {
                    tooOld = true;
                }
                else
                {
                    //age is valid, ask for weight
                    System.out.print("Enter weight in kg: ");
                    weight = scandra.nextDouble();
                    //determine healthy limits based on entered weight
                    healthyUpper = ((5*age)/12)+5;
                    healthyLower = (age/3)+2;
                    if(weight < 2 || weight > 15)
                    {
                        weightInvalid = true;
                    }
                    else
                    {
                        if(weight <= healthyUpper && weight >= healthyLower)
                        {
                            System.out.println("Age/weight is in the healthy" + 
                            " range!");
                        }
                        else if(weight > healthyUpper)
                        {
                            System.out.println("Too heavy");
                        }
                        else if(weight < healthyLower)
                        {
                            System.out.println("Too light");
                        }
                    }
                }
                break;
            
            case 3:
                //ask for age
                System.out.print("Enter in the age in months: ");
                age = scandra.nextDouble();
                if(age < 0)
                {
                    tooYoung = true;
                }
                else if(age > 24)
                {
                    tooOld = true;
                }
                else
                {
                    //age is valid, ask for weight
                    System.out.print("Enter weight in pounds: ");
                    weight = scandra.nextDouble();
                    //convert pounds to kg
                    weight = weight * 0.45359237;
                    //determine healthy limits based on entered weight
                    healthyUpper = ((5*age)/12)+5;
                    healthyLower = (age/3)+2;
                    if(weight < 2 || weight > 15)
                    {
                        weightInvalid = true;
                    }
                    else
                    {
                        if(weight <= healthyUpper && weight >= healthyLower)
                        {
                            System.out.println("Age/weight is in the healthy" + 
                            " range!");
                        }
                        else if(weight > healthyUpper)
                        {
                            System.out.println("Too heavy");
                        }
                        else if(weight < healthyLower)
                        {
                            System.out.println("Too light");
                        }
                    }
                }
                break;
            
            case 4:
                //ask for age
                System.out.print("Enter in the age in years: ");
                age = scandra.nextDouble();
                //convert years to months
                age = age * 12;
                if(age < 0)
                {
                    tooYoung = true;
                }
                else if(age > 24)
                {
                    tooOld = true;
                }
                else
                {
                    //age is valid, ask for weight
                    System.out.print("Enter weight in pounds: ");
                    weight = scandra.nextDouble();
                    //convert pounds to kg
                    weight = weight * 0.45359237;
                    //determine healthy limits based on entered weight
                    healthyUpper = ((5*age)/12)+5;
                    healthyLower = (age/3)+2;
                    if(weight < 2 || weight > 15)
                    {
                        weightInvalid = true;
                    }
                    else
                    {
                        if(weight <= healthyUpper && weight >= healthyLower)
                        {
                            System.out.println("Age/weight is in the healthy" + 
                            " range!");
                        }
                        else if(weight > healthyUpper)
                        {
                            System.out.println("Too heavy");
                        }
                        else if(weight < healthyLower)
                        {
                            System.out.println("Too light");
                        }
                    }
                }
                break;
            
            default:
                //if user enters a number other than 1, 2, 3, or 4
                System.out.println("Error, invalid choice");
                break;
                 
        }
        //if something is wrong, program comes here
        if(tooOld)
        {
            System.out.println("Error, too old");
        }
        else if(tooYoung)
        {
            System.out.println("Error, too young");
        }
        else if(weightInvalid)
        {
            System.out.println("Error, invalid weight");
        }
    }
}
