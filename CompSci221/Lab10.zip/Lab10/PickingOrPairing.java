import java.util.Scanner;
import java.util.Random;
/**
 * Write a description of class PickingOrPairing here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PickingOrPairing
{
    public static void main(String[] args)
    {
        //variables
        Random rndm = new Random();
        Scanner scnr = new Scanner(System.in);
        String[] peopleIn;
        String[] pickedPeople;
        String choice;
        int[] randChoices;
        int hmnyPeople;
        int hmnyChoices;
        int i, j, k;
        int longest = 0;
        int randomNum = -1;
        boolean pickOrPair = false;
        boolean pickAndPair = false;
        boolean alreadyPicked = true;
        
        //ask the user for number of people
        System.out.print("How many people? ");
        hmnyPeople = scnr.nextInt();
        //clear scanner
        scnr.nextLine();
        peopleIn = new String[hmnyPeople];
        System.out.println("Enter the names");
        for(i = 1; i <= peopleIn.length; i++)
        {
            System.out.print("Person " + i + ": ");
            peopleIn[i-1] = scnr.nextLine();
        }
        for(i = 0; i < peopleIn.length; i++)
        {
            if(peopleIn[i].length() > longest)
            {
                longest = peopleIn[i].length();
            }
        }
        while(!pickAndPair)
        {
            System.out.print("Are we picking or pairing? ");
            choice = scnr.nextLine();
            switch(choice)
            {
                case "picking":
                    pickOrPair = false;
                    pickAndPair = true;
                    break;
                case "pairing":
                    pickOrPair = true;
                    pickAndPair = true;
                    break;
                default:
                    pickAndPair = false;
                    System.out.println("Invalid input");
            }
        }
        //enters if pairing is selected
        if(pickOrPair)
        {
            System.out.println("The possible pairs are:");
            for(i = 0; i < peopleIn.length; i++)
            {
                for(j = 0; j < peopleIn.length; j++)
                {
                    if(j == i)
                    {
                        if(j != peopleIn.length-1)
                        {
                            j++;
                            System.out.printf("P1: %" + longest + "s, P2: %s\n", peopleIn[i], peopleIn[j]);
                        }
                    }
                    else if(j < peopleIn.length)
                    {
                        System.out.printf("P1: %" + longest + "s, P2: %s\n", peopleIn[i], peopleIn[j]);
                    }
                }
            }
        }
        //enters if picking is selected
        else if(!pickOrPair)
        {
            System.out.print("How many shall I pick? ");
            hmnyChoices = scnr.nextInt();
            pickedPeople = new String[hmnyChoices];
            randChoices = new int[hmnyChoices];
            for(i = 0; i < pickedPeople.length ; i++)
            {
                alreadyPicked = true;
                while(alreadyPicked)
                {
                    
                    alreadyPicked = false;
                    randomNum = rndm.nextInt(peopleIn.length - 1);
                    for(j = 0; j < pickedPeople.length; j++)
                    {
                        if(randomNum == randChoices[j])
                        {
                            alreadyPicked = true;
                        }
                    }
                }
                randChoices[i] = randomNum;
                pickedPeople[i] = peopleIn[randomNum];
            }
            for(i = 0; i < pickedPeople.length ; i++)
            {
                if(i != pickedPeople.length - 1)
                {
                    System.out.print(pickedPeople[i] + ", ");
                }
                else
                {
                    System.out.print(pickedPeople[i]);
                }
            }
        }
    }
}
