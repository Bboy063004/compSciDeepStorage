import java.util.Scanner;
import java.util.Random;
/**
 * A program that makes simple math flashcards
 *
 * @author Bobby Wienke
 * @version 3/22/2024
 */
public class multiplicationFlashcards
{
    public static void main(String args[])
    {
        //woo, variables
        int numOfFlash;
        int numOne;
        int numTwo;
        int userAnswer;
        int correctAnswer;
        int correct = 0;
        int total = 0;
        Random randal = new Random();
        Scanner scandra = new Scanner(System.in);
        
        //ask for num of flashcards
        System.out.print("Enter number of flashcards: ");
        numOfFlash = scandra.nextInt();
        
        while(numOfFlash > 0)
        {
            System.out.println("\n----");
            numOne = randal.nextInt(0, 10);
            numTwo = randal.nextInt(0, 10);
            correctAnswer = numOne * numTwo;
            System.out.println("| " + numOne + "|");
            System.out.println("|x" + numTwo + "|");
            System.out.println("----");
            System.out.print("= ");
            userAnswer = scandra.nextInt();
            if(userAnswer == correctAnswer)
            {
                System.out.println("Correct!");
                correct++;
            }
            else
            {
                System.out.println("Incorrect (" + correctAnswer + ")");
            }
            total++;
            numOfFlash--;
        }
        System.out.println("\nYou got " + correct + "/" + total + " correct.");
        System.out.println("Come practice again soon!");
    }
}
