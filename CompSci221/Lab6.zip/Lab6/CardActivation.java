import java.util.Scanner;
/**
 * Write a description of class CardActivation here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CardActivation
{
    public static void main(String args[])
    {
        //wooo, variables
        Scanner scnr = new Scanner(System.in);
        String firstName;
        char firstOfFirst;
        String lastName;
        String botString; 
        boolean botCheck;
        String firstFourOfFirst;
        int operatorNum = 0;
        String cardNumber;
        String pin;
        String cardType;
        
        
        //ask user for their name and assign operator
        System.out.print("Enter your full name: ");
        firstName = scnr.next();
        firstOfFirst = Character.toUpperCase(firstName.charAt(0));
        if(firstOfFirst < 75)
        {
            operatorNum = 1;
        }
        else if (firstOfFirst < 84)
        {
            operatorNum = 2;
        }
        else if( firstOfFirst < 91)
        {
            operatorNum = 3;
        }
        lastName = scnr.nextLine();
        
        //bot check
        System.out.print("Please enter up to the first four letters of your first name: ");
        botString = scnr.nextLine();
        firstFourOfFirst = firstName.substring(0, 4);
        botCheck = firstFourOfFirst.equalsIgnoreCase(botString);
        if(!botCheck)
        {
            //bot check failed
            System.out.print("We cannot trust that you are not a robot.");
            System.out.println("Good bye. ");
        }
        else
        {
            //bot check passed
            //operator introduction
            System.out.println("\nYou are being directed to Operator " + operatorNum + " ... \n");
            System.out.println("Hello, I'm Operator " + operatorNum + "!");
            
            
            System.out.print("Please enter your card number: ");
            cardNumber = scnr.nextLine();
            
            //check card number
            if(cardNumber.length() != 16)
            {
                System.out.println("Invalid card number");
            }
            else
            {
                //find card type
                if(cardNumber(
                
                
                
                System.out.println("Thank you for setting up your Visa card.");
                System.out.print("Please enter a PIN: ");
                pin = scnr.nextLine();
            }
            
        }
    }
}
