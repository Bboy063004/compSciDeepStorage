
/**
 * I am Bobby Wienke, I'm a CompSci major. i chose UWO because of the
 * the marching band. In the future, I hope to become a video game developer.
 *
 * @author Bobby Wienke
 * @version 2/9/2024
 */
public class FirstLab
{
    public static void main(String[] args)
    {
        System.out.println("Hello World!");
        System.out.print("Hail Titans! ");
        System.out.println("Hail Titans! ");
        System.out.print("Sons strong and mighty ");
        System.out.println("of the U W O ");
        System.out.print("Hail Titans! ");
        System.out.println("Hail Titans! ");
        System.out.print("Titans to victory! ");
    }
}
