
/**
 * Write a description of class Face here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Face
{
    public static void main(String[] args)
    {
        // draw top of the head
        System.out.println("   _ _ _"); 
        // draw the eyebrows
        System.out.println("  | _ _ |"); 
        // draw the eyes
        System.out.println("  | - 0 |"); 
        // draw the ears and the nose
        System.out.println(" {|  >  |}"); 
        // draw the mouth
        System.out.println("  |[---]|"); 
        // draw the bottom of head
        System.out.println("  |_ _ _|"); 
    }
}
