import java.util.Scanner;
/**
 * A game where you have to pick a number for the program to check for, then you enter numbers until you get to a number that either
 * is divisible by the "buzz number" or a number that contains the "buzz number"
 *
 * @author Bobby Wienke
 * @version 4/16/2024
 */
public class Buzz
{
    public static void main(String[] args)
    {
        //variables
        Scanner scandral = new Scanner(System.in);
        int buzzNum = 1;
        int gameNum = 0;
        int currentNum = 1;
        int curScore = 0;
        int highScore = 0;
        int lowScore = 0;
        int totalScore = 0;
        int userInNum;
        int whileTest;
        Double averageScore = 0.0;
        String userIn;
        char userYesNo;
        boolean buzzedRight = true;
        boolean continueBool = true;
        boolean hasBuzzNum = false;
        boolean validInput = false;
        boolean containsBuzz = false;
        
        System.out.print("Let's play Buzz!\n\n");
        while(continueBool)
        {
            curScore = 0;
            buzzedRight = true;
            gameNum++;
            //show how many times has been played
            System.out.println("GAME " + gameNum);
            //ask for starting number
            System.out.print("Which number would you like to start at? ");
            currentNum = scandral.nextInt();
            //ask for the number to check
            System.out.print("What's your buzz number? ");
            buzzNum = scandral.nextInt();
            System.out.print("Great, starting at " + currentNum + ", buzzing ");
            System.out.println(buzzNum + ", Go!");
            while(buzzedRight)
            {
                whileTest = currentNum;
                containsBuzz = false;
                validInput = false;
                //checks if the buzz number is in the number being checked
                while(whileTest > 0)
                {
                    if(whileTest % 10 == buzzNum)
                    {
                        containsBuzz = true;
                    }
                    whileTest = whileTest / 10;
                }
                userIn = scandral.next();
                scandral.nextLine();
                //checks if the check number is divisible by the buzz number
                if(currentNum % buzzNum == 0 || containsBuzz)
                {
                    if(userIn.equals("buzz"))
                    {
                        currentNum++;
                        curScore++;
                    }
                    else
                    {
                        System.out.println("Should have buzzed");
                        buzzedRight = false;
                    }
                }
                //checks if isnt divisible by buzz number
                else if(currentNum % buzzNum != 0 )
                {
                    if(!(userIn.equals("buzz")))
                    {
                        userInNum = Integer.parseInt(userIn);
                        if(userInNum != currentNum)
                        {
                            System.out.print("Wrong number! (You were on ");
                            System.out.println(currentNum + ")");
                            buzzedRight = false;
                        }
                        else
                        {
                            currentNum++;
                            curScore++;
                        }
                    }
                    else
                    {
                        System.out.println("Not a Buzz! (" + currentNum + ")");
                    }
                }
            }
            //makes it so the high and low score get set, and aren't stuck at a different number for eternity
            if(gameNum == 1)
            {
                highScore = curScore;
                lowScore = curScore;
            }
            //checks high score compaerd to current score
            else if(curScore > highScore)
            {
                highScore = curScore;
            }
            //checks lowest score compared to current score
            else if(curScore < lowScore)
            {
                lowScore = curScore;
            }
            //total scores added to find the average
            totalScore += curScore;
            //finds the average
            averageScore = (double)(totalScore) / gameNum;
            System.out.println("GAME OVER! Score: " + curScore + "\n");
            //game stats section
            System.out.println("------------------------------");
            System.out.println("GAME STATS:");
            System.out.printf("%15s: %d\n","Games played", gameNum);
            System.out.printf("%15s: %d\n","Highest score", highScore);
            System.out.printf("%15s: %d\n","Lowest score", lowScore);
            System.out.printf("%15s: %.2f\n","Average score", averageScore);
            System.out.println("------------------------------\n");
            //loops so that the user enters either y or n and doesnt accept anything else
            while(!validInput)
            {
                System.out.print("Would you like to play again (y/n): ");
                userYesNo = scandral.next().charAt(0);
                //checks y or n
                switch(userYesNo)
                {
                    case 'n':
                    case 'N':
                        continueBool = false;
                        validInput = true;
                        break;
                    case 'y':
                    case 'Y':
                        continueBool = true;
                        validInput = true;
                        break;
                    default:
                        validInput = false;
                        System.out.println("Invalid input, enter y or n");
                        break;
                        
                }
            }
        }
        System.out.println("\nThanks for playing!");
    }
}
