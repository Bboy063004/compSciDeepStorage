import java.util.Scanner;
/**
 * Checks a user entered string for any duplicate letters
 *
 * @author Bobby Wienke
 * @version 04/11/2024
 */
public class DuplicateLetters
{
    public static void main(String[] args)
    {
        //variables
        Scanner scandy = new Scanner(System.in);
        String input;
        boolean isDuplicate = false;
        int curCharPos = 0;
        int checkCharPos = 1;
        
        //Ask the user for the text
        System.out.print("Text: ");
        input = scandy.nextLine();
        
        //start checing the characters for a duplicate
        while(curCharPos < input.length()-1 && !isDuplicate)
        {
            //enter this if there is a duplicate at curCharPos and checkCharPos
            if(input.charAt(curCharPos) == input.charAt(checkCharPos))
            {
                isDuplicate = true;
            }
            //enter this if there isnt a duplicate at curCharPos and
            //checkCharPos, and if checkCharPos is at the input length minus 1
            else if(checkCharPos == input.length()-1)
            {
                System.out.println("Switching to checking " + input.charAt(curCharPos));
                curCharPos++;
                checkCharPos = curCharPos + 1;
            }
            //enter this if none are true, so that the next character 
            //can be checked
            else
            {
                System.out.println("checking " + input.charAt(checkCharPos));
                checkCharPos++;
            }
        }
        //enter if there is a duplicate letter
        if(isDuplicate)
        {
            System.out.println("\n" + input + " has duplicate letters.");
        }
        //enter if there isnt a duplicate letter
        else
        {
            System.out.println("\n" + input + " has no duplicate letters.");
        }
    }
}
