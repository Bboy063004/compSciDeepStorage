import java.util.Scanner;
/**
 * checks a user entered string for all of the duplicat letters and outputs
 * wich letter has the most duplicates, and how many there are
 *
 * @author Bobby Wienke
 * @version 04/11/2024
 */
public class MostOccuringLetter
{
    public static void main(String[] args)
    {
        //Woo, variables
        Scanner chefScanner = new Scanner(System.in);
        String input;
        char most = ' ';
        char current, curCheck;
        int counter, mostCounter = 0;
        int i, j;
        //Ask the user for their input
        System.out.print("Text: ");
        input = chefScanner.nextLine().toLowerCase();
        
        for(i = 0; i < input.length(); i++)
        {
            current = input.charAt(i);
            counter = 1;
            for(j = i; j < input.length(); j++)
            {
                curCheck = input.charAt(j);
                if(current == curCheck)
                {
                    counter++;
                }
                if(counter > mostCounter)
                {
                    most = current;
                    mostCounter = counter;
                }
            }
        }
        System.out.println(most + " occurs the most! (" + mostCounter + " times)");
    }
}
