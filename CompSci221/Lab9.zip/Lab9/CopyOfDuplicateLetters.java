import java.util.Scanner;
/**
 * Checks a user entered string for any duplicate letters
 *
 * @author Bobby Wienke
 * @version 04/11/2024
 */
public class CopyOfDuplicateLetters
{
    public static void main(String[] args)
    {
        //variables
        Scanner scandy = new Scanner(System.in);
        String input;
        boolean isDuplicate = false;
        int curCharPos = 0;
        //int checkCharPos = 1;
        
        //Ask the user for the text
        System.out.print("Text: ");
        input = scandy.nextLine();
        
        //start checing the characters for a duplicate
        while(curCharPos < input.length()-1 && !isDuplicate)
        {
            //enter this if there is a duplicate at curCharPos and checkCharPos
            isDuplicate = input.indexOf(input.charAt(curCharPos), curCharPos + 1) >= 0;
            
            curCharPos++;
        }
        //enter if there is a duplicate letter
        if(isDuplicate)
        {
            System.out.println("\n" + input + " has duplicate letters.");
        }
        //enter if there isnt a duplicate letter
        else
        {
            System.out.println("\n" + input + " has no duplicate letters.");
        }
    }
}
