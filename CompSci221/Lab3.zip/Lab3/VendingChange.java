import java.util.Scanner;
/**
 * Figures out the change from a vending machine
 *
 * @author Bobby Wienke
 * @version 2/22/2024
 */
public class VendingChange
{
    public static void main(String[] args){
        Scanner scnr = new Scanner(System.in);
        
        //Declare variables
        double itemCost;
        int dollars;
        int centsOwed;
        int quarters;
        int dimes;
        int nickels;
        int pennies;
        final int CENTS_PER_QUARTER = 25;
        final int CENTS_PER_DIME = 10;
        final int CENTS_PER_NICKEL = 5;
        
        //Ask and recieve cost of items
        System.out.print("Item cost: $");
        itemCost = scnr.nextDouble();
        scnr.nextLine();
        
        //Ask and recieve total paid
        System.out.print("Number of dollars: $");
        dollars = scnr.nextInt();
        scnr.nextLine();
        
        //Calculate change owed
        centsOwed = (int)(((1000 * dollars) - (1000 * itemCost)) / 10);
        
        //Output the change owed
        System.out.println("");
        System.out.println("Change: " + centsOwed + " cents");
        
        //Calculate quarters owed and find remaining balance
        quarters = centsOwed / CENTS_PER_QUARTER;
        centsOwed = centsOwed % CENTS_PER_QUARTER;
        
        //Calculate dimes owed and find remaining balance
        dimes = centsOwed / CENTS_PER_DIME;
        centsOwed = centsOwed % CENTS_PER_DIME;
        
        //Calculate nickels owed and find remaining balance
        nickels = centsOwed / CENTS_PER_NICKEL;
        pennies = centsOwed % CENTS_PER_NICKEL;
        
        //Output values
        System.out.println(quarters + " quarter(s)");
        System.out.println(dimes + " dime(s)");
        System.out.println(nickels + " nickel(s)");
        System.out.println(pennies + " penny(ies)");
    }
}
