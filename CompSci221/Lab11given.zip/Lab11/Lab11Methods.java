// DO NOT USE SCANNER IN THIS LAB!!!
import java.util.Random;
/**
 * Contains general purpose utility methods
 * including:
 * - charNTimes
 * - maskN
 * - allPairsOf
 * - pickFrom
 * - pickPair
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Lab11Methods {
    /**
     * Returns a String with the given character
     * repeated a given number of times.
     *
     * @param character Character to repeat
     * @param n Number of times to repeat the given character
     * @return String with the given character repeated the 
     *         given number of times
     */
    public static String charNTimes(char character, int n) {
        String charRepeated = "";
        for(int i = 0; i < n; i++) {
            charRepeated += character;
        }
        return charRepeated;
    }
    
    
    /**
     * Returns a String with the given text where the beginning
     * given number of characters are "masked" with
     * a given mask character. 
     * 
     * If the given number of characters is 
     * longer than the text itself, the returned String will 
     * contain the given mask character repeated the given number of
     * times. This effectively masks the length of the original
     * given text as well.
     *
     * @param text text to mask
     * @param n Number of characters to mask
     * @param maskChar Character to mask with
     * @return String with the given text where the beginning given number
     *         of characters are masked with the given mask character,
     *         or the given mask character repeated n times if n is 
     *         longer than the length of the text
     */
    //#TODO: Implement maskN method here
    
        
    /**
     * Returns an array of all pairs of values from the 
     * first given array paired with all values from the
     * second given array separated by the given separator.
     * 
     * For example, all pairs of {"A", "B", "C"} and
     * {"Y", "Z"} separated by "/"
     * returns {"A/Y", "A/Z", "B/Y", "B/Z", "C/Y", "C/Z"}
     *
     * @param firstArray Values for front half of pairs
     * @param secondArray Values for end half of pairs
     * @param separator Value to connect the values in each pair
     * @return all pairs of values from the first given array
     *         paired with values form the second given array
     */
    public static String[] allPairsOf(String[] firstArray, String[] secondArray, String separator) {
        String[] pairs = new String[firstArray.length * secondArray.length];
        
        int index = 0;
        for(String firstVal : firstArray) {
            for(String secondVal : secondArray) {
                pairs[index] = firstVal + separator + secondVal;
                index++;
            }
        }
        
        return pairs;
    }
    
    
    /**
     * Returns an array of all pairs of values from the 
     * first given array paired with all values from the
     * second given array.
     * 
     * For example, all pairs of {"A", "B", "C"} and
     * {"Y", "Z"} returns {"AY", "AZ", "BY", "BZ", "CY", "CZ"}
     *
     * @param firstArray Values for front half of pairs
     * @param secondArray Values for end half of pairs
     * @return all pairs of values from the first given array
     *         paired with values form the second given array
     */
    //#TODO: Implement allPairsOf method here
    
    
        
    /**
     * Randomly pick and return n options 
     * from the given options;
     * The original given array of options
     * will remain unchanged.
     * The same option cannot be picked 
     * more than once.
     *
     * @param n Number of options to pick, should be
     *          less than or equal to the length of the
     *          options
     * @param options String array of options to pick from
     * @return A new array with n options randomly picked
     *         in a random order.
     */
    //#TODO: Implement pickFrom method here
    
    
    /**
     * Randomly pick and return all options 
     * from the given options;
     * The original given array of options
     * will remain unchanged.
     *
     * @param options String array of options to pick from
     * @return A new array with all of the options picked
     *         in a random order.
     */
    //#TODO: Implement pickFrom method here
    
    
    /**
     * Randomly pick one item from the firstOptions
     * and one item from the secondOptions
     * and return them as an array.
     *
     * @param firstOptions Options to pick from for the 
     *                     first item in the pair
     * @param secondOptions Options to pick from for the
     *                      second item in the pair
     * @return the pair picked stored in an array of size 2
     */
    //#TODO: Implement pickPair method here
    
    
    public static void main(String[] args) {
        
        // 1. charNTimes tests:
        System.out.println("charNTimes TESTS:");
        System.out.println();
        
        System.out.println("Testing '&' and 12: ");
        System.out.println("Expected: &&&&&&&&&&&&");
        System.out.println("Actual:   " + 
                            charNTimes('&', 12));
        System.out.println();
        
        System.out.println("Testing 't' and 5: ");
        System.out.println("Expected: ttttt");
        System.out.println("Actual:   " + 
                            charNTimes('t', 5));
        System.out.println();
        
        System.out.println("Testing '-' and 0: ");
        System.out.println("Expected: ");
        System.out.println("Actual:   " + 
                            charNTimes('-', 0));
        System.out.println();
        
        //#TODO Add your own charNTimes test(s) here:
        System.out.println("TODO: Add your own charNTimes test(s)");
        
        
        
        
        // 2. maskN tests:
        System.out.println();
        System.out.println("--------------------------------------");
        System.out.println("maskN TESTS:");
        System.out.println();
        
        String testString = "1111222233334444";
        System.out.println("Testing \"1111222233334444\", 12, '*': ");
        System.out.println("Expected: ************4444");
        System.out.println("Actual:   " + 
                            maskN(testString, 12, '*'));
        System.out.println();
        
        System.out.println("Testing \"1111222233334444\", 20, '0': ");
        System.out.println("Expected: 00000000000000000000");
        System.out.println("Actual:   " + 
                            maskN(testString, 20, '0'));
        System.out.println();
        
        testString = "1234";                    
        System.out.println("Testing \"1234\", 4, '-': ");
        System.out.println("Expected: ----");
        System.out.println("Actual:   " + 
                            maskN(testString, 4, '-'));                    
        System.out.println();
        
        //#TODO Add your own maskN test(s) here:
        System.out.println("TODO: Add your own maskN test(s)");
        
        
        
        
        
        
        // Making some arrays for testing:
        String[] suits = {"Clubs", "Diamonds", "Hearts", "Spades"};
        String[] ranks = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9",
                          "10", "Jack", "Queen", "King"};
        
        String[] letters = {"A", "B", "C"};
        String[] endLetters = {"Y", "Z"};
        
        
        // 3. allPairsOf:
        System.out.println();
        System.out.println("--------------------------------------");
        System.out.println("allPairsOf with separator TESTS:");
        System.out.println();
        
        System.out.println("Testing {A, B, C} and {Y, Z} and \"/\": ");
        System.out.println("Expected: {A/Y, A/Z, B/Y, B/Z, C/Y, C/Z}");
        System.out.print("Actual:   ");
        outputArray(allPairsOf(letters, endLetters, "/"));
        System.out.println();
        
        System.out.println("Testing {ranks} and {suits} with \" of \": ");
        String[] deck = allPairsOf(ranks, suits, " of ");
        outputArray(deck);
        System.out.println();
        
        String[] snacks = {"crackers", "cheese"};
        String[] drinks = {"coffee", "tea", "milk", "wine"};
        System.out.println("Testing {snacks} and {drinks} with \" and \": ");
        String[] snackDrinkCombos = allPairsOf(snacks, drinks, " and ");
        outputArray(snackDrinkCombos);
        System.out.println();
        
        //#TODO Add your own allPairsOf with separator test(s) here:
        System.out.println("TODO: Add your own allPairsOf with separator test(s)");
        
        
        // 4. allPairsOf:
        System.out.println();
        System.out.println("--------------------------------------");
        System.out.println("allPairsOf TESTS:");
        System.out.println();
        
        System.out.println("Testing {A, B, C} and {Y, Z}: ");
        System.out.println("Expected: {AY, AZ, BY, BZ, CY, CZ}");
        System.out.print("Actual:   ");
        outputArray(allPairsOf(letters, endLetters));
        System.out.println();
        
        System.out.println("Testing {A, B, C} and {A, B, C}: ");
        System.out.println("Expected: {AA, AB, AC, BA, BB, BC, CA, CB, CC}");
        System.out.print("Actual:   ");
        outputArray(allPairsOf(letters, letters));
        System.out.println();
        
        //#TODO Add your own allPairsOf test(s) here:
        System.out.println("TODO: Add your own allPairsOf test(s)");
        
        
        
        // 5. pickFrom:
        System.out.println();
        System.out.println("--------------------------------------");
        System.out.println("pickFrom TESTS:");
        System.out.println();
        
        String[] people = {"Lorelai", "Rory", "Luke", "Suki"};
        for(int i = 0; i <= people.length; i++) {
            System.out.printf("Testing pick %d from ", i);
            outputArray(people);
            System.out.printf("Expected: %d of ", i);
            outputArray(people);
            System.out.print("Actual:   ");
            outputArray(pickFrom(i, people));
            System.out.println();
        }
        
        for(int i = 0; i <= snacks.length; i++) {
            System.out.printf("Testing pick %d from ", i);
            outputArray(snacks);
            System.out.printf("Expected: %d of ", i);
            outputArray(snacks);
            System.out.print("Actual:   ");
            outputArray(pickFrom(i, snacks));
            System.out.println();
        }
        
        for(int i = 0; i < 5; i++) {
            System.out.println("Testing pick 5 from {deck of cards}");
            System.out.print("Actual:   ");
            outputArray(pickFrom(5, deck));
            System.out.println();
        }
        
        //#TODO Add your own pickFrom test(s) here:
        System.out.println("TODO: Add your own pickFrom test(s)");
        
        
        // 6. pickFrom:
        System.out.println();
        System.out.println("--------------------------------------");
        System.out.println("pickFrom TESTS:");
        System.out.println();
        
        for(int i = 0; i < 2; i++) {
            System.out.print("Testing pick from ");
            outputArray(people);
            System.out.print("Expected: random order of ");
            outputArray(people);
            System.out.print("Actual:   ");
            outputArray(pickFrom(people));
            System.out.println();
        }
        
        for(int i = 0; i < 2; i++) {
            System.out.print("Testing pick from ");
            outputArray(snacks);
            System.out.print("Expected: random order of ");
            outputArray(snacks);
            System.out.print("Actual:   ");
            outputArray(pickFrom(snacks));
            System.out.println();
        }
        
        String[] one = {"one is the loneliest number"};
        for(int i = 0; i < 2; i++) {
            System.out.print("Testing pick from ");
            outputArray(one);
            System.out.print("Expected: ");
            outputArray(one);
            System.out.print("Actual:   ");
            outputArray(pickFrom(one));
            System.out.println();
        }
        
        //#TODO Add your own pickFrom test(s) here:
        System.out.println("TODO: Add your own pickFrom test(s)");
        
        
        // 7. pickPair:
        System.out.println();
        System.out.println("--------------------------------------");
        System.out.println("pickPair TESTS:");
        System.out.println();
        
        System.out.println("Testing {A, B, C} and {Y, Z}: ");
        System.out.println("Expected: {one of {A, B, C}, one of {Y, Z}}");
        System.out.print("Actual:   ");
        outputArray(pickPair(letters, endLetters));
        System.out.println();
        
        for(int i = 0; i < 5; i++) {
            System.out.println("Testing {ranks} and {suits}: ");
            System.out.println("Expected: {a rank, a suit}");
            System.out.print("Actual:   ");
            outputArray(pickPair(ranks, suits));
            System.out.println();
        }
        
        //#TODO Add your own pickPair test(s) here:
        System.out.println("TODO: Add your own pickPair test(s)");
        
    }
    
    /**
     * Method to output an array of Strings
     * surrounded by curly braces { }
     * with values comma-separated
     *
     * @param array Values to output
     */
    public static void outputArray(String[] array) {
        System.out.print("{");
        if(array.length > 0) {
            System.out.print(array[0]);
        }
        for(int i = 1; i < array.length; i++) {
            System.out.print(", " + array[i]);
        }
        System.out.println("}");
    }
}
