import java.util.Random;
/**
 * Gets 3 random characters and creates a string from them
 *
 * @author Bobby Wienke
 * @version 2/29/2024
 */
public class RandCharleader
{
    public static void main(String args[])
    {
        //Variables, woo
        Random randGen = new Random();
        char char1;
        char char2;
        char char3;
        String result;
        String special = "@#$%^&*()";
        
        //assign chars to char1, 2, and 3
        char1 = (char)randGen.nextInt(65,91);
        char2 = (char)randGen.nextInt(97,123);
        char3 = (char)special.charAt(randGen.nextInt(special.length()));
        result = "" + char1 + char2 + char3;
         
        //Outputs the chars and string
        System.out.println("Give me a " + char1 + "!");
        System.out.println("Give me a " + char2 + "!");
        System.out.println("Give me a " + char3 + "!");
        System.out.println("What's that spell?");
        System.out.println(result + "!");
     }
}
