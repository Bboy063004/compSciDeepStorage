import java.util.Random;
import java.util.Scanner;
/**
 * Finds a value of the fibonacci sequence
 *
 * @author Bobby Wienke
 * @version 2/29/2024
 */
public class RandFib
{
    public static void main(String args[])
    {
        //Woo, variables
        Random randGen = new Random();
        Scanner scnr = new Scanner(System.in);
        final double SQRT_FIVE = Math.sqrt(5.0);
        final double PHI = (1 + SQRT_FIVE) / 2;
        int min;
        int max;
        int n;
        long fibAtN;
        
        //Ask for min and max and assign them to values
        System.out.print("Min N: ");
        min  = scnr.nextInt();
        System.out.print("Max N: ");
        max = scnr.nextInt();
        
        //Randomly select a number within the min and max
        n = randGen.nextInt(min, max + 1);
        System.out.println("comuting F" + n);

        //Calculate fibonacci value at n
        fibAtN = (long)Math.round(((Math.pow(PHI, n)-Math.pow((1-PHI), n))/
                                (SQRT_FIVE)));
        
        //output fibAtN
        System.out.println("F" + n + " is " + fibAtN);
    }
}
