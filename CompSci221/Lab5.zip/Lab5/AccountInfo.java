import java.util.Scanner;
/**
 * Write a description of class AccountInfo here.
 *
 * @author Bobby Wienke
 * @version 03/08/2024
 */
public class AccountInfo
{
     public static void main(String[] args) {

 

    // import/initialize the scanner.

    Scanner scnr = new Scanner(System.in);

 

    // Deffine the variables.

    String usersName;

    String firstName;

    String lastName;

    String userCredCrdNum;

    String userName;

    int credCardLength;

    String lastFourDgts;

 

    // Ask the user for their full name.

    System.out.print("Enter full name: ");

    usersName = scnr.nextLine();

 

    // Ask the user for their credit card number.

    System.out.print("Enter Credit card: ");

    userCredCrdNum = scnr.nextLine();

 

    // Separate the first and Last names.

    int space = usersName.indexOf(' ');

    firstName = usersName.substring(0, space);

    lastName = usersName.substring(space + 1);

    // Get the credit card number and separate the last 4 digits.

    credCardLength = userCredCrdNum.length();

    lastFourDgts = userCredCrdNum.substring(credCardLength - 4);

 

    // Generate the UserName

    userName = lastName.toLowerCase() +

        firstName.substring(0, 1).toLowerCase();

 

    // Print message welcoming the user

    // and printing back the user's last 4 credit card digits.

    System.out.println();

    System.out.println("Welcome:  \"" + firstName + "\"!");

    System.out.println("Your username is: " + userName);

    System.out.println("Credit card: ************" + lastFourDgts);

 

    scnr.close();

  }
}
