import java.util.Scanner;


/**
 * Write a description of class TitanTreats here.
 *
 * @author Bobby Wienke
 * @version 03/08/2024
 */
public class TitanTreats
{
    public static void main(String[] args) {

 

    // import / initalize the scanner.

    Scanner scnr = new Scanner(System.in);

 

    // Deffine le Variables...

    int numOfCupCakes;

    double cupCakePrice;

    int numOfFrostColor;

    double frostSprnkPrice = 0;

    int numOfSprinkles;

    double totalPrice;

    int numOfFillings;

    String deliveryAdress;

    int indexCommaTwo;

    int indexSpace;

    // Address declaration confined to one line for "optimization."

    String street, city, state, zipCode, zip;

 

    // define the prices of the items with final(s) [Constants]

    final double BASE_PRICE = 2.50;

    final double PRICE_PER_CAKE_LESS_THN_5 = 1.50;

    final double PRICE_PER_CAKE_5_TO_9 = 1.25;

    final double PRICE_PER_CAKE_10_TO_19 = 1.00;

    final double PRICE_PER_CAKE_20_OR_MORE = 0.75;

    final double FROSING_SPRINKLES_ADDITIONAL_COLOR_FEE = 1.00;

    final double FROSTING_SPRINKLES_ADDITIONAL_BOTH_COLOR_FEE = 1.50;

    final double FILLING_FEE = 2.00;

    final double DELIVERY_FEE = 3.99;

 

    // Welcome the user

    System.out.println("Welcome to Titan Treats!");

    System.out.println(" ");

 

    // Ask for user input / "Order"

    System.out.println("Please place your cupcake order:");

 

    // Get the number of cupcakes

    System.out.print("Number of Cupcakes: ");

    numOfCupCakes = scnr.nextInt();

 

    // Get the number of frosting colors

    System.out.print("Number of frosting colors (1 included):");

    numOfFrostColor = scnr.nextInt();

 

    // Get the number of sprinkles

    System.out.print("Number of sprinkles colors (1 included): ");

    numOfSprinkles = scnr.nextInt();

 

    // Get the number of desired fillings

    System.out.print("Number of fillings (0 included): ");

    numOfFillings = scnr.nextInt();

    scnr.nextLine();

 

    // Get the users delivery address

    System.out.print("Delivery address (or just press Enter for pickup instead): ");

    deliveryAdress = scnr.nextLine();

 

    // Calculate the Cupcakes price

    if (numOfCupCakes < 5) {

      cupCakePrice = numOfCupCakes * PRICE_PER_CAKE_LESS_THN_5;

    } else if (numOfCupCakes <= 9) {

      cupCakePrice = numOfCupCakes * PRICE_PER_CAKE_5_TO_9;

    } else if (numOfCupCakes <= 19) {

      cupCakePrice = numOfCupCakes * PRICE_PER_CAKE_10_TO_19;

    } else {

      cupCakePrice = numOfCupCakes * PRICE_PER_CAKE_20_OR_MORE;

    }

 

    // Calculate the price with the addition of frosting and da sprinkles

    if (numOfFrostColor > 1 && numOfSprinkles > 1) {

      frostSprnkPrice = FROSTING_SPRINKLES_ADDITIONAL_BOTH_COLOR_FEE;

    } else if (numOfFrostColor > 1 || numOfSprinkles > 1) {

      frostSprnkPrice = FROSING_SPRINKLES_ADDITIONAL_COLOR_FEE;

    }

 

    // Calculate the final Price

    totalPrice = (BASE_PRICE + cupCakePrice + frostSprnkPrice +

        (numOfFillings * FILLING_FEE));

    totalPrice = Math.round(totalPrice * 100.0) / 100.0;

 

    // Print the orders prices and info for the customer

    System.out.println();

    System.out.println("Thank you for your order! ");

    if (deliveryAdress.length() == 0) {

      System.out.println("That will be $ " + totalPrice + " for pickup");

    } else {

      totalPrice += DELIVERY_FEE;

      System.out.print("That will be $ ");

      System.out.printf("%.2f", totalPrice);

      System.out.println();

      System.out.println("Delivering to: ");

 

      // Seperate out the Street and print

      int indexComma = deliveryAdress.indexOf(",");

      indexCommaTwo = deliveryAdress.indexOf(',', indexComma + 1);

      street = deliveryAdress.substring(0, indexComma);

      System.out.println("Street: " + street);

 

      // Seperate out the City

      indexCommaTwo = deliveryAdress.indexOf(", ", indexComma + 2);

      city = deliveryAdress.substring(indexComma + 2, indexCommaTwo);

      System.out.println("City: " + city);

 

      // Seperate out the zip and state

      zipCode = deliveryAdress.substring(indexCommaTwo + 2);

      indexSpace = zipCode.indexOf(" ");

      state = zipCode.substring(0, indexSpace);

      zip = zipCode.substring(indexSpace + 1);

      System.out.println("State: " + state);

      System.out.println("ZIP: " + zip);

    }

 

    scnr.close();

  }
}
