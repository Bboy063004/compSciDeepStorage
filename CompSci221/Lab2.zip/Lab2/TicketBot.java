import java.util.Scanner;
/**
 * A bot that says it's going to find you tickets to where ever you want, and is
 * about as helpful as any other bot
 *
 * @author Bobby Wienke
 * @version 2/15/2024
 */
public class TicketBot
{
    public static void main(String[] args)
    {
        //Define scanner
        Scanner scnr = new Scanner(System.in);
        //Define variables
        String fullName;
        int ticketNum;
        String location;
        double ticketPrice;
        
        //Print introduction section, and get name of user
        System.out.println("Welcome to TicketBot!");
        System.out.print("Please start with your full name: ");
        fullName = scnr.nextLine();
        System.out.println("Thank you " + fullName);
        
        //Get how many tickets the user needs
        System.out.print("How many tickets do you need: ");
        //Puts the number of tickets into variable ticketNum
        ticketNum = scnr.nextInt();
        System.out.println("I will search for options with " + ticketNum + 
                           " ticket(s) available!");
        //Clear scanner
        scnr.nextLine();
        
        //Get where the user wants to go
        System.out.print("Where is it that you would like tickets to: ");
        location = scnr.nextLine();
        
        //Get the users spending limit
        System.out.print("How much are you hoping to spend maximum: $");
        ticketPrice = scnr.nextDouble();
        System.out.print("Understood, I won't show you options above $");
        System.out.printf("%.2f", ticketPrice);
        System.out.println();
        
        //Summarize the responces
        System.out.println("To summarize, you would like:");
        System.out.println(ticketNum + " ticket(s) to " + location);
        System.out.print("at no more than $");
        System.out.printf("%.2f", ticketPrice);
        System.out.println(" per ticket.");
        System.out.println("Loading options...");
        
    }
}
